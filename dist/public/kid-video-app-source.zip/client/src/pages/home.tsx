import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Play, Pause, Plus, Trash2, CheckCircle, Lock, ArrowLeft, User, Video, Sparkles, Star, Youtube, Loader2,
  Baby, Smile, PersonStanding, Glasses, Bot, Mic, MicOff, Eye, AlertTriangle, Settings, X, Volume2, Pencil, Check, Link, FolderPlus, Folder as FolderIcon, ChevronDown, ChevronRight, Music2, Clipboard, Download, LogOut, Square, RotateCcw, SkipForward, MessageSquare, Camera, Send, Image, Globe, Gift
} from "lucide-react";
import { SiTiktok } from "react-icons/si";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { AVATARS, AVATAR_CONFIG, MAX_VIDEO_VIEWS, VIDEO_PRIORITY_DEFAULT, getVideoInfo } from "@shared/schema";
import type { Kid, Video as VideoType, VoiceRecording, Folder, VideoPlatform } from "@shared/schema";

// Safe avatar config getter with fallback
function getAvatarConfig(avatar: string) {
  return AVATAR_CONFIG[avatar as keyof typeof AVATAR_CONFIG] || { label: "Child", color: "from-purple-400 to-pink-400" };
}

// TikTok thumbnail component with caching
const tiktokThumbnailCache = new Map<string, string>();

function TikTokThumbnail({ videoId, className = "" }: { videoId: string; className?: string }) {
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(tiktokThumbnailCache.get(videoId) || null);
  const [loading, setLoading] = useState(!tiktokThumbnailCache.has(videoId));
  const [error, setError] = useState(false);

  useEffect(() => {
    if (tiktokThumbnailCache.has(videoId)) {
      setThumbnailUrl(tiktokThumbnailCache.get(videoId)!);
      setLoading(false);
      return;
    }

    fetch(`/api/tiktok-thumbnail/${videoId}`)
      .then(res => res.ok ? res.json() : Promise.reject())
      .then(data => {
        if (data.thumbnailUrl) {
          tiktokThumbnailCache.set(videoId, data.thumbnailUrl);
          setThumbnailUrl(data.thumbnailUrl);
        } else {
          setError(true);
        }
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [videoId]);

  if (loading) {
    return (
      <div className={`bg-gradient-to-br from-pink-500 via-red-500 to-cyan-500 flex items-center justify-center ${className}`}>
        <Loader2 className="w-5 h-5 text-white animate-spin" />
      </div>
    );
  }

  if (error || !thumbnailUrl) {
    return (
      <div className={`bg-gradient-to-br from-pink-500 via-red-500 to-cyan-500 flex items-center justify-center ${className}`}>
        <SiTiktok className="w-6 h-6 text-white" />
      </div>
    );
  }

  return (
    <img 
      src={thumbnailUrl} 
      alt="TikTok video thumbnail"
      className={`object-cover ${className}`}
      onError={() => setError(true)}
    />
  );
}

// Avatar icon component
function AvatarIcon({ avatar, className = "w-6 h-6" }: { avatar: string; className?: string }) {
  const iconProps = { className };
  switch (avatar) {
    case "child":
      return <PersonStanding {...iconProps} />;
    case "girl":
      return <Smile {...iconProps} />;
    case "boy":
      return <User {...iconProps} />;
    case "baby":
      return <Baby {...iconProps} />;
    case "cool":
      return <Glasses {...iconProps} />;
    case "robot":
      return <Bot {...iconProps} />;
    default:
      return <User {...iconProps} />;
  }
}

export default function Home() {
  const { toast } = useToast();
  
  // Check URL for direct kid mode (using route params like /kid/:kidId)
  const [isKidRoute, routeParams] = useRoute("/kid/:kidId");
  const kidParam = isKidRoute ? routeParams?.kidId : null;
  
  // Check URL path directly on initial load (for PWA/iOS compatibility)
  const getInitialKidId = () => {
    const path = window.location.pathname;
    const match = path.match(/^\/kid\/(.+)$/);
    if (match) {
      // Save to localStorage for PWA persistence
      localStorage.setItem('lockedKidId', match[1]);
      return match[1];
    }
    // Check if there's a saved kid from a previous PWA session
    const savedKidId = localStorage.getItem('lockedKidId');
    if (savedKidId) {
      return savedKidId;
    }
    return null;
  };
  
  const initialKidId = getInitialKidId();
  
  // Check if we should be in locked mode (from URL or saved PWA state)
  const isLockedKidMode = (isKidRoute && Boolean(kidParam)) || Boolean(localStorage.getItem('lockedKidId'));
  
  // App state - initialize based on URL path or saved PWA state
  const [mode, setMode] = useState<"parent" | "kid">(initialKidId ? "kid" : "parent");
  const [activeKidId, setActiveKidId] = useState<string>(initialKidId || "kid1");
  
  // Also sync mode when route hook updates (handles in-app navigation)
  useEffect(() => {
    if (isKidRoute && kidParam) {
      // Save to localStorage for PWA persistence
      localStorage.setItem('lockedKidId', kidParam);
      setMode("kid");
      setActiveKidId(kidParam);
    }
  }, [isKidRoute, kidParam]);
  
  // Parent forms
  const [newKidName, setNewKidName] = useState("");
  const [newKidAvatar, setNewKidAvatar] = useState<typeof AVATARS[number]>(AVATARS[0]);
  const [videoUrl, setVideoUrl] = useState("");
  const [selectedKidIds, setSelectedKidIds] = useState<string[]>([]); // empty = all kids
  const [assignToAll, setAssignToAll] = useState(true);
  const [videoPriority, setVideoPriority] = useState<number | null>(null);
  
  // Kid watch state
  const [watchingVideoId, setWatchingVideoId] = useState<string | null>(null);
  const [videoEnded, setVideoEnded] = useState(false);
  const [tiktokStarted, setTiktokStarted] = useState(false);
  const [watchProgress, setWatchProgress] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [ytIsPlaying, setYtIsPlaying] = useState(false);
  const [ytCurrentTime, setYtCurrentTime] = useState(0);
  const [ytIsDragging, setYtIsDragging] = useState(false);
  const [ytDragValue, setYtDragValue] = useState(0);
  const ytWatchedTimeRef = useRef<number>(0);
  const ytLastTickRef = useRef<number>(0);
  const ytWaitTimerRef = useRef<NodeJS.Timeout | null>(null);
  const youtubePlayerRef = useRef<any>(null);
  const youtubeIframeRef = useRef<HTMLIFrameElement | null>(null);
  const youtubePlayerContainerRef = useRef<HTMLDivElement | null>(null);
  const ytTimerRef = useRef<NodeJS.Timeout | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const tiktokStartTimeRef = useRef<number>(0);
  const videoStartTimeRef = useRef<number>(0);
  
  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [hasRecording, setHasRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [liveRecordingTime, setLiveRecordingTime] = useState(0);
  const [audioDataUrl, setAudioDataUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingStartTimeRef = useRef<number>(0);
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Settings dialog state
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [editingKidId, setEditingKidId] = useState<string | null>(null);
  const [editingKidName, setEditingKidName] = useState("");
  
  // Folder state
  const [newFolderName, setNewFolderName] = useState("");
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(["unfiled"]));
  
  // Video preview state
  const [previewingVideoId, setPreviewingVideoId] = useState<string | null>(null);
  
  // Delete confirmation state
  const [deletingFolderId, setDeletingFolderId] = useState<string | null>(null);
  const [deletingVideoId, setDeletingVideoId] = useState<string | null>(null);
  
  // Folder editing state
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [isFolderEditMode, setIsFolderEditMode] = useState(false);
  const [editingFolderName, setEditingFolderName] = useState("");
  
  // Add to home screen state
  const [showHomeScreenInstructions, setShowHomeScreenInstructions] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  // Activity stats dialog state
  const [activityStatsKidId, setActivityStatsKidId] = useState<string | null>(null);
  
  // Activity detail view state (drilldown into specific time period)
  const [activityDetailView, setActivityDetailView] = useState<{
    kidId: string;
    period: 'today' | 'week' | 'month' | 'day';
    date?: Date; // for specific day from 7-day chart
  } | null>(null);
  
  // Audio playback state for activity detail
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const activityAudioRef = useRef<HTMLAudioElement | null>(null);
  
  // Auth
  const { user, isAuthenticated } = useAuth();
  
  // Feedback state
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [feedbackType, setFeedbackType] = useState<'text' | 'voice' | 'video' | 'screenshot'>('text');
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackRecording, setFeedbackRecording] = useState(false);
  const [feedbackAudioData, setFeedbackAudioData] = useState<string | null>(null);
  const [feedbackAudioDuration, setFeedbackAudioDuration] = useState(0);
  const [feedbackScreenshot, setFeedbackScreenshot] = useState<string | null>(null);
  const [feedbackVideoUrl, setFeedbackVideoUrl] = useState("");
  const feedbackMediaRecorderRef = useRef<MediaRecorder | null>(null);
  const feedbackAudioChunksRef = useRef<Blob[]>([]);
  const feedbackRecordingStartRef = useRef<number>(0);
  const feedbackRecordingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [feedbackLiveTime, setFeedbackLiveTime] = useState(0);

  // Global playlists state
  const [showGlobalPlaylists, setShowGlobalPlaylists] = useState(false);
  
  useEffect(() => {
    if (!isLockedKidMode) {
      fetch("/api/kids/cleanup-duplicates", { method: "POST", credentials: "include" })
        .then(r => r.ok ? r.json() : null)
        .then(data => {
          if (data?.removed > 0) {
            queryClient.invalidateQueries({ queryKey: ["/api/kids"] });
            queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
          }
        })
        .catch(() => {});
    }
  }, [isLockedKidMode]);

  // Detect platform for home screen instructions
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isAndroid = /Android/.test(navigator.userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
  
  // Capture the beforeinstallprompt event for Android
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);
  
  // Handle Android install prompt
  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        toast({ title: "App installed!", description: "You can now open it from your home screen." });
      }
      setDeferredPrompt(null);
      setShowHomeScreenInstructions(false);
    } else if (isIOS) {
      // iOS doesn't support programmatic install, just show instructions
      setShowHomeScreenInstructions(true);
    } else {
      setShowHomeScreenInstructions(true);
    }
  };

  // Fetch kids - use public endpoint in kid mode
  const usePublicEndpoints = isLockedKidMode && !!initialKidId;
  const { data: kids = [], isLoading: kidsLoading } = useQuery<Kid[]>({
    queryKey: usePublicEndpoints
      ? ["/api/public/kid", initialKidId]
      : ["/api/kids"],
    ...(usePublicEndpoints ? {
      queryFn: async () => {
        const res = await fetch(`/api/public/kid/${initialKidId}`);
        if (!res.ok) return [];
        const kid = await res.json();
        return [kid];
      }
    } : {}),
    staleTime: 1000 * 30,
    refetchOnMount: "always",
  });

  // Fetch videos - use public endpoint in kid mode
  const { data: videos = [], isLoading: videosLoading } = useQuery<VideoType[]>({
    queryKey: usePublicEndpoints
      ? ["/api/public/kid", initialKidId, "videos"]
      : ["/api/videos"],
    ...(usePublicEndpoints ? {
      queryFn: async () => {
        const res = await fetch(`/api/public/kid/${initialKidId}/videos`);
        if (!res.ok) return [];
        return res.json();
      }
    } : {}),
    staleTime: 1000 * 30,
    refetchOnMount: "always",
  });

  // Fetch folders - use public endpoint in kid mode
  const { data: folders = [], isLoading: foldersLoading } = useQuery<Folder[]>({
    queryKey: usePublicEndpoints
      ? ["/api/public/kid", initialKidId, "folders"]
      : ["/api/folders"],
    ...(usePublicEndpoints ? {
      queryFn: async () => {
        const res = await fetch(`/api/public/kid/${initialKidId}/folders`);
        if (!res.ok) return [];
        return res.json();
      }
    } : {}),
    staleTime: 1000 * 30,
    refetchOnMount: "always",
  });

  // Global playlists queries (only for parent mode)
  const { data: isMasterData } = useQuery<{ isMaster: boolean }>({
    queryKey: ["/api/global/is-master"],
    enabled: !usePublicEndpoints,
    staleTime: 1000 * 60 * 5,
  });
  const isMaster = isMasterData?.isMaster || false;

  const { data: globalPlaylists = [] } = useQuery<(Folder & { videoCount: number })[]>({
    queryKey: ["/api/global/playlists"],
    enabled: !usePublicEndpoints,
    staleTime: 1000 * 60,
  });

  const { data: globalSubscriptions = [] } = useQuery<{ id: string; userId: string; masterFolderId: string; kidIds: string[] }[]>({
    queryKey: ["/api/global/subscriptions"],
    enabled: !usePublicEndpoints,
    staleTime: 1000 * 30,
  });

  const { data: trialStatus } = useQuery<{ daysLeft: number; show: boolean; frozen: boolean }>({
    queryKey: ["/api/trial-status"],
    enabled: !usePublicEndpoints,
    staleTime: 1000 * 60 * 60,
  });

  const subscribeMutation = useMutation({
    mutationFn: async ({ masterFolderId, kidIds }: { masterFolderId: string; kidIds: string[] }) => {
      const res = await apiRequest("POST", "/api/global/subscribe", { masterFolderId, kidIds });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/global/subscriptions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      toast({ title: "Subscribed!", description: "Playlist videos added to your library." });
    },
    onError: () => {
      toast({ title: "Failed to subscribe", variant: "destructive" });
    },
  });

  const unsubscribeMutation = useMutation({
    mutationFn: async ({ masterFolderId }: { masterFolderId: string }) => {
      const res = await apiRequest("POST", "/api/global/unsubscribe", { masterFolderId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/global/subscriptions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      toast({ title: "Unsubscribed", description: "Playlist removed from your library." });
    },
    onError: () => {
      toast({ title: "Failed to unsubscribe", variant: "destructive" });
    },
  });

  const activeKid = useMemo(() => 
    kids.find(k => k.id === activeKidId) || kids[0], 
    [kids, activeKidId]
  );

  // PWA badge: set home screen badge count
  useEffect(() => {
    if (!('setAppBadge' in navigator)) return;
    
    const setBadge = async () => {
      try {
        if (isLockedKidMode && initialKidId) {
          const res = await fetch(`/api/public/kid/${initialKidId}/badge`);
          if (res.ok) {
            const { count } = await res.json();
            if (count > 0) {
              (navigator as any).setAppBadge(count);
            } else {
              (navigator as any).clearAppBadge();
            }
          }
        } else if (mode === "parent" && kids.length > 0) {
          const res = await fetch('/api/badge/parent', { credentials: 'include' });
          if (res.ok) {
            const { count } = await res.json();
            if (count > 0) {
              (navigator as any).setAppBadge(count);
            } else {
              (navigator as any).clearAppBadge();
            }
          }
        }
      } catch {}
    };
    
    setBadge();
  }, [isLockedKidMode, initialKidId, mode, videos, kids]);

  // Auto-clear parent badge when parent views the home screen
  useEffect(() => {
    if (mode !== "parent" || isLockedKidMode) return;
    
    const clearBadge = async () => {
      try {
        await fetch('/api/badge/parent/clear', { method: 'POST', credentials: 'include' });
        if ('clearAppBadge' in navigator) {
          (navigator as any).clearAppBadge();
        }
      } catch {}
    };
    
    const timeout = setTimeout(clearBadge, 3000);
    return () => clearTimeout(timeout);
  }, [mode, isLockedKidMode]);

  // Get videos assigned to active kid
  const assignedVideos = useMemo(() => 
    videos.filter(v => v.assigned?.[activeKid?.id]), 
    [videos, activeKid]
  );

  // Group assigned videos by folder for kid view (sorted by priority)
  const kidVideosByFolder = useMemo(() => {
    const groups: { id: string; name: string; videos: typeof assignedVideos }[] = [];
    
    // Group by folder
    const folderMap = new Map<string | null, typeof assignedVideos>();
    assignedVideos.forEach(video => {
      const folderId = video.folderId ?? null;
      if (!folderMap.has(folderId)) {
        folderMap.set(folderId, []);
      }
      folderMap.get(folderId)!.push(video);
    });
    
    // Add folder groups (sort videos by priority)
    folders.forEach(folder => {
      const folderVideos = folderMap.get(folder.id) || [];
      if (folderVideos.length > 0) {
        const sortedVideos = [...folderVideos].sort((a, b) => (a.priority || 5) - (b.priority || 5));
        const globalMatch = folder.name.match(/^__global_(.+)$/);
        const masterPlaylist = globalMatch ? globalPlaylists.find(gp => gp.id === globalMatch[1]) : null;
        const displayName = masterPlaylist ? masterPlaylist.name : (globalMatch ? "Curated Playlist" : folder.name);
        groups.push({ id: folder.id, name: displayName, videos: sortedVideos });
      }
    });
    
    // Add unfiled videos (also sorted by priority)
    const unfiledVideos = folderMap.get(null) || [];
    if (unfiledVideos.length > 0) {
      const sortedUnfiled = [...unfiledVideos].sort((a, b) => (a.priority || 5) - (b.priority || 5));
      groups.push({ id: "unfiled", name: "Other Videos", videos: sortedUnfiled });
    }
    
    return groups;
  }, [assignedVideos, folders, globalPlaylists]);

  // Check if a video is locked (requires lower priority videos to be watched first)
  const isVideoLocked = useCallback((video: VideoType, folderVideos: VideoType[], kidId: string) => {
    const videoPriority = video.priority || 5;
    // Find all videos with lower priority that haven't been watched
    const unwatchedLowerPriority = folderVideos.filter(v => {
      const vPriority = v.priority || 5;
      return vPriority < videoPriority && !v.progress?.[kidId]?.watched;
    });
    return unwatchedLowerPriority.length > 0;
  }, []);

  // Get stats for a kid
  const getKidStats = useCallback((kidId: string) => {
    const assigned = videos.filter(v => v.assigned?.[kidId]);
    const watched = assigned.filter(v => v.progress?.[kidId]?.watched).length;
    return { watched, pending: assigned.length - watched, total: assigned.length };
  }, [videos]);

  // Get detailed activity stats for a kid (daily, weekly, monthly)
  const getDetailedActivityStats = useCallback((kidId: string) => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setDate(startOfWeek.getDate() - 6);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const assigned = videos.filter(v => v.assigned?.[kidId]);
    const totalAssigned = assigned.length;
    
    // Count ALL watched videos (including legacy data without timestamps)
    const allWatchedVideos = assigned.filter(v => v.progress?.[kidId]?.watched);
    const totalCompleted = allWatchedVideos.length;
    
    // Get completed videos WITH timestamps for time-based breakdown
    const datedCompletions = allWatchedVideos
      .filter(v => v.progress?.[kidId]?.watchedAt)
      .map(v => ({
        video: v,
        watchedAt: new Date(v.progress[kidId].watchedAt!)
      }));
    
    // Count legacy completions without dates
    const undatedCompletions = totalCompleted - datedCompletions.length;
    
    // Filter by time periods (only dated completions)
    const completedToday = datedCompletions.filter(c => c.watchedAt >= startOfToday).length;
    const completedThisWeek = datedCompletions.filter(c => c.watchedAt >= startOfWeek).length;
    const completedThisMonth = datedCompletions.filter(c => c.watchedAt >= startOfMonth).length;
    
    // Get recent activity (last 7 days breakdown)
    const last7Days: { date: string; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(startOfToday);
      date.setDate(date.getDate() - i);
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);
      const count = datedCompletions.filter(c => c.watchedAt >= date && c.watchedAt < nextDate).length;
      last7Days.push({
        date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        count
      });
    }
    
    return {
      totalAssigned,
      totalCompleted,
      pending: totalAssigned - totalCompleted,
      completedToday,
      completedThisWeek,
      completedThisMonth,
      last7Days,
      undatedCompletions,
      completionRate: totalAssigned > 0 ? Math.round((totalCompleted / totalAssigned) * 100) : 0
    };
  }, [videos]);

  // Get videos watched in a specific time period for a kid
  const getVideosForPeriod = useCallback((kidId: string, period: 'today' | 'week' | 'month' | 'day', specificDate?: Date) => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    let startDate: Date;
    let endDate: Date = new Date(startOfToday.getTime() + 24 * 60 * 60 * 1000); // end of today
    
    if (period === 'today') {
      startDate = startOfToday;
    } else if (period === 'week') {
      startDate = new Date(startOfToday);
      startDate.setDate(startDate.getDate() - startDate.getDay());
    } else if (period === 'month') {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (period === 'day' && specificDate) {
      startDate = new Date(specificDate.getFullYear(), specificDate.getMonth(), specificDate.getDate());
      endDate = new Date(startDate.getTime() + 24 * 60 * 60 * 1000);
    } else {
      startDate = startOfToday;
    }
    
    const assigned = videos.filter(v => v.assigned?.[kidId]);
    const watchedVideos = assigned
      .filter(v => {
        const progress = v.progress?.[kidId];
        if (!progress?.watched || !progress?.watchedAt) return false;
        const watchedAt = new Date(progress.watchedAt);
        return watchedAt >= startDate && watchedAt < endDate;
      })
      .sort((a, b) => {
        const aDate = new Date(a.progress?.[kidId]?.watchedAt || 0);
        const bDate = new Date(b.progress?.[kidId]?.watchedAt || 0);
        return bDate.getTime() - aDate.getTime(); // Latest first
      });
    
    return watchedVideos;
  }, [videos]);

  // Create kid mutation
  const createKidMutation = useMutation({
    mutationFn: async (data: { name: string; avatar: typeof AVATARS[number] }) => {
      const response = await apiRequest("POST", "/api/kids", data);
      return response.json();
    },
    onSuccess: (kid: Kid) => {
      queryClient.invalidateQueries({ queryKey: ["/api/kids"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setNewKidName("");
      setNewKidAvatar(AVATARS[0]);
      toast({ title: "Kid added!", description: `${kid.name} has been added successfully.` });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error?.message || "Failed to add kid.", variant: "destructive" });
    },
  });

  // Update kid mutation
  const updateKidMutation = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const response = await apiRequest("PATCH", `/api/kids/${id}`, { name });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/kids"] });
      setEditingKidId(null);
      setEditingKidName("");
      toast({ title: "Name updated!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update name.", variant: "destructive" });
    },
  });

  // Delete kid mutation
  const deleteKidMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/kids/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/kids"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({ title: "Kid removed" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove kid.", variant: "destructive" });
    },
  });

  // Create folder mutation
  const createFolderMutation = useMutation({
    mutationFn: async ({ name }: { name: string }) => {
      const response = await apiRequest("POST", "/api/folders", { name });
      return response.json();
    },
    onSuccess: (folder: Folder) => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setNewFolderName("");
      setExpandedFolders(prev => new Set([...Array.from(prev), folder.id]));
      toast({ title: "Folder created!", description: `"${folder.name}" folder has been added.` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create folder.", variant: "destructive" });
    },
  });

  // Delete folder mutation
  const deleteFolderMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/folders/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] }); // Videos may have changed folderId
      setSelectedFolderId(null);
      setDeletingFolderId(null);
      toast({ title: "Folder deleted" });
    },
    onError: () => {
      setDeletingFolderId(null);
      toast({ title: "Error", description: "Failed to delete folder.", variant: "destructive" });
    },
  });

  // Update folder mutation
  const updateFolderMutation = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const response = await apiRequest("PATCH", `/api/folders/${id}`, { name });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/folders"] });
      setEditingFolderId(null);
      setEditingFolderName("");
      toast({ title: "Folder renamed!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to rename folder.", variant: "destructive" });
    },
  });

  // Create video mutation
  const createVideoMutation = useMutation({
    mutationFn: async ({ url, kidIds, folderId, priority }: { url: string; kidIds?: string[]; folderId?: string | null; priority?: number }) => {
      const response = await apiRequest("POST", "/api/videos", { url, kidIds, folderId, priority });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setVideoUrl("");
      setSelectedKidIds([]);
      setAssignToAll(true);
      setVideoPriority(null);
      const desc = assignToAll ? "The video has been added for all kids." : "The video has been added for selected kids.";
      toast({ title: "Video added!", description: desc });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add video. Check if the URL is valid.", variant: "destructive" });
    },
  });

  // Delete video mutation
  const deleteVideoMutation = useMutation({
    mutationFn: async (videoId: string) => {
      await apiRequest("DELETE", `/api/videos/${videoId}`);
    },
    onSuccess: (_, videoId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      // Close preview if this video was being previewed
      if (previewingVideoId === videoId) {
        setPreviewingVideoId(null);
      }
      setDeletingVideoId(null);
      toast({ title: "Video removed", description: "The video has been removed from the library." });
    },
    onError: () => {
      setDeletingVideoId(null);
      toast({ title: "Error", description: "Failed to delete video.", variant: "destructive" });
    },
  });

  // Update video mutation (priority, folder)
  const updateVideoMutation = useMutation({
    mutationFn: async ({ videoId, priority, folderId }: { videoId: string; priority?: number; folderId?: string | null }) => {
      await apiRequest("PATCH", `/api/videos/${videoId}`, { priority, folderId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update video.", variant: "destructive" });
    },
  });

  // Mark video watched mutation (requires voice recording)
  const markWatchedMutation = useMutation({
    mutationFn: async ({ videoId, kidId, voiceRecording }: { videoId: string; kidId: string; voiceRecording: VoiceRecording }) => {
      if (isLockedKidMode && initialKidId) {
        const res = await fetch(`/api/public/kid/${initialKidId}/videos/${videoId}/watched`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ voiceRecording }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: "Failed" }));
          throw new Error(err.error || "Failed to mark video as watched");
        }
        return res.json();
      }
      const response = await apiRequest("POST", `/api/videos/${videoId}/watched/${kidId}`, { voiceRecording });
      return response.json();
    },
    onSuccess: () => {
      if (isLockedKidMode && initialKidId) {
        queryClient.invalidateQueries({ queryKey: ["/api/public/kid", initialKidId, "videos"] });
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      }
      setWatchingVideoId(null);
      setVideoEnded(false);
      setHasRecording(false);
      setRecordingDuration(0);
      toast({ title: "Great job!", description: "Video completed! Keep up the good work!" });
    },
    onError: (error: Error) => {
      const msg = error.message || "Failed to mark video as completed.";
      toast({ title: "Error", description: msg, variant: "destructive" });
    },
  });

  // Feedback mutation
  const feedbackMutation = useMutation({
    mutationFn: async (data: { type: string; content: string }) => {
      const response = await apiRequest("POST", "/api/feedback", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Thank you!", description: "Your feedback has been submitted." });
      setFeedbackOpen(false);
      resetFeedbackForm();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to submit feedback. Please try again.", variant: "destructive" });
    },
  });

  // Reset feedback form
  const resetFeedbackForm = useCallback(() => {
    setFeedbackType('text');
    setFeedbackText("");
    setFeedbackAudioData(null);
    setFeedbackAudioDuration(0);
    setFeedbackScreenshot(null);
    setFeedbackVideoUrl("");
    setFeedbackRecording(false);
    setFeedbackLiveTime(0);
  }, []);

  // Feedback voice recording
  const startFeedbackRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      feedbackMediaRecorderRef.current = mediaRecorder;
      feedbackAudioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) feedbackAudioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(feedbackAudioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          setFeedbackAudioData(reader.result as string);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      feedbackRecordingStartRef.current = Date.now();
      setFeedbackLiveTime(0);
      feedbackRecordingIntervalRef.current = setInterval(() => {
        setFeedbackLiveTime(Math.floor((Date.now() - feedbackRecordingStartRef.current) / 1000));
      }, 100);

      mediaRecorder.start();
      setFeedbackRecording(true);
    } catch (error) {
      toast({ title: "Microphone error", description: "Could not access microphone.", variant: "destructive" });
    }
  }, [toast]);

  const stopFeedbackRecording = useCallback(() => {
    if (feedbackMediaRecorderRef.current && feedbackRecording) {
      feedbackMediaRecorderRef.current.stop();
      setFeedbackRecording(false);
      if (feedbackRecordingIntervalRef.current) {
        clearInterval(feedbackRecordingIntervalRef.current);
      }
      setFeedbackAudioDuration(Math.floor((Date.now() - feedbackRecordingStartRef.current) / 1000));
    }
  }, [feedbackRecording]);

  // Handle screenshot upload
  const handleScreenshotUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFeedbackScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  // Submit feedback
  const submitFeedback = useCallback(() => {
    let content = "";
    if (feedbackType === 'text') {
      content = feedbackText.trim();
      if (!content) {
        toast({ title: "Missing feedback", description: "Please enter your feedback.", variant: "destructive" });
        return;
      }
    } else if (feedbackType === 'voice') {
      if (!feedbackAudioData) {
        toast({ title: "Missing recording", description: "Please record your feedback.", variant: "destructive" });
        return;
      }
      content = feedbackAudioData;
    } else if (feedbackType === 'screenshot') {
      if (!feedbackScreenshot) {
        toast({ title: "Missing screenshot", description: "Please upload a screenshot.", variant: "destructive" });
        return;
      }
      content = feedbackScreenshot;
    } else if (feedbackType === 'video') {
      content = feedbackVideoUrl.trim();
      if (!content) {
        toast({ title: "Missing video link", description: "Please paste a video link.", variant: "destructive" });
        return;
      }
    }
    feedbackMutation.mutate({ type: feedbackType, content });
  }, [feedbackType, feedbackText, feedbackAudioData, feedbackScreenshot, feedbackVideoUrl, feedbackMutation, toast]);

  // Add a new kid
  const addKid = useCallback(() => {
    const name = newKidName.trim();
    if (!name) {
      toast({ title: "Missing name", description: "Please enter a name for the kid.", variant: "destructive" });
      return;
    }
    if (kids.length >= 6) {
      toast({ title: "Limit reached", description: "You can add up to 6 kids.", variant: "destructive" });
      return;
    }
    createKidMutation.mutate({ name, avatar: newKidAvatar });
  }, [newKidName, newKidAvatar, kids.length, toast, createKidMutation]);

  // Add a new folder
  const addFolder = useCallback(() => {
    const name = newFolderName.trim();
    if (!name) {
      toast({ title: "Missing name", description: "Please enter a folder name.", variant: "destructive" });
      return;
    }
    createFolderMutation.mutate({ name });
  }, [newFolderName, toast, createFolderMutation]);

  // Add a new video
  // Check if URL is a TikTok short link that needs resolution
  const isTikTokShortUrl = useCallback((url: string): boolean => {
    try {
      const u = new URL(url);
      const host = u.hostname.replace('www.', '').toLowerCase();
      return host === 'vm.tiktok.com' || (host === 'tiktok.com' && u.pathname.startsWith('/t/'));
    } catch {
      return false;
    }
  }, []);

  // State for resolving TikTok URLs
  const [isResolvingUrl, setIsResolvingUrl] = useState(false);

  const addVideo = useCallback(async () => {
    let normalized = videoUrl.trim();
    if (!normalized) {
      toast({ title: "Missing link", description: "Please paste a YouTube or TikTok link.", variant: "destructive" });
      return;
    }
    
    // Check if it's a TikTok short URL that needs resolution
    if (isTikTokShortUrl(normalized)) {
      setIsResolvingUrl(true);
      try {
        const response = await apiRequest("POST", "/api/resolve-tiktok-url", { url: normalized });
        const data = await response.json();
        if (data.resolvedUrl) {
          normalized = data.resolvedUrl;
          setVideoUrl(normalized); // Update the input with resolved URL
          toast({ title: "Link resolved!", description: "TikTok short link converted to full URL." });
        } else {
          toast({ title: "Invalid link", description: "Could not resolve TikTok short link.", variant: "destructive" });
          setIsResolvingUrl(false);
          return;
        }
      } catch {
        toast({ title: "Error", description: "Could not resolve TikTok short link. Please use the full TikTok URL.", variant: "destructive" });
        setIsResolvingUrl(false);
        return;
      }
      setIsResolvingUrl(false);
    }
    
    const videoInfo = getVideoInfo(normalized);
    if (!videoInfo) {
      toast({ title: "Invalid link", description: "Please paste a valid YouTube or TikTok link.", variant: "destructive" });
      return;
    }

    // Check if folder is selected
    if (selectedFolderId === null) {
      toast({ title: "No folder selected", description: "Please select a folder for this video.", variant: "destructive" });
      return;
    }

    // Check if priority level is selected
    if (videoPriority === null) {
      toast({ title: "No level selected", description: "Please select a priority level (1-9).", variant: "destructive" });
      return;
    }

    // Check if specific kids selected
    if (!assignToAll && selectedKidIds.length === 0) {
      toast({ title: "No kids selected", description: "Please select at least one kid or choose 'All Kids'.", variant: "destructive" });
      return;
    }

    const kidIds = assignToAll ? undefined : selectedKidIds;
    const folderId = selectedFolderId === "unfiled" ? null : selectedFolderId;
    createVideoMutation.mutate({ url: normalized, kidIds, folderId, priority: videoPriority });
  }, [videoUrl, toast, createVideoMutation, assignToAll, selectedKidIds, selectedFolderId, videoPriority, isTikTokShortUrl]);

  // Paste video URL from clipboard - always focus input first, then try clipboard
  const pasteFromClipboard = useCallback(async () => {
    // Focus input immediately (synchronous, within user gesture)
    const input = document.querySelector('[data-testid="input-video-url"]') as HTMLInputElement;
    if (input) {
      input.focus();
    }
    
    // Now try to read clipboard and paste
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim()) {
          setVideoUrl(text.trim());
        }
      }
    } catch {
      // Clipboard API failed - input is already focused for manual paste
    }
  }, []);

  // Start editing a folder name
  const startEditingFolder = useCallback((folder: Folder) => {
    setEditingFolderId(folder.id);
    setEditingFolderName(folder.name);
  }, []);

  // Save edited folder name
  const saveEditingFolder = useCallback(() => {
    if (!editingFolderId) return;
    const name = editingFolderName.trim();
    if (!name) {
      toast({ title: "Name required", description: "Please enter a folder name.", variant: "destructive" });
      return;
    }
    updateFolderMutation.mutate({ id: editingFolderId, name });
  }, [editingFolderId, editingFolderName, toast, updateFolderMutation]);

  // Cancel editing folder
  const cancelEditingFolder = useCallback(() => {
    setEditingFolderId(null);
    setEditingFolderName("");
  }, []);

  // Toggle folder expansion
  const toggleFolder = useCallback((folderId: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderId)) {
        next.delete(folderId);
      } else {
        next.add(folderId);
      }
      return next;
    });
  }, []);

  // Remove a video (triggers confirmation dialog)
  const removeVideo = useCallback((videoId: string) => {
    setDeletingVideoId(videoId);
  }, []);

  // Load YouTube IFrame API
  useEffect(() => {
    if ((window as any).YT) return;
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);
  }, []);

  // Create YouTube player when watching a YouTube video in kid mode
  useEffect(() => {
    if (mode !== 'kid' || !watchingVideoId) return;
    const watchingVideo = videos.find(v => v.id === watchingVideoId);
    if (!watchingVideo || watchingVideo.platform !== 'youtube') return;

    ytWatchedTimeRef.current = 0;
    ytLastTickRef.current = 0;

    const createPlayer = () => {
      if (!youtubePlayerContainerRef.current) return;
      if (youtubePlayerRef.current) {
        try { youtubePlayerRef.current.destroy(); } catch {}
        youtubePlayerRef.current = null;
      }

      const viewCount = watchingVideo.totalViews || 0;
      const isFirstWatch = viewCount === 0;
      const requiredPercent = isFirstWatch ? 90 : 60;

      youtubePlayerRef.current = new (window as any).YT.Player(youtubePlayerContainerRef.current, {
        videoId: watchingVideo.ytId,
        playerVars: {
          playsinline: 1,
          controls: 0,
          rel: 0,
          fs: 0,
          modestbranding: 1,
          disablekb: 1,
          autoplay: 1,
        },
        events: {
          onReady: (event: any) => {
            const dur = event.target.getDuration() || 0;
            setVideoDuration(dur);
            event.target.playVideo();
            ytLastTickRef.current = Date.now();

            if (ytTimerRef.current) clearInterval(ytTimerRef.current);
            ytTimerRef.current = setInterval(() => {
              const p = youtubePlayerRef.current;
              if (!p || typeof p.getCurrentTime !== 'function') return;
              const cur = p.getCurrentTime() || 0;
              const d = p.getDuration() || dur;
              setYtCurrentTime(cur);
              setVideoDuration(d);

              const state = p.getPlayerState?.();
              const isPlaying = state === (window as any).YT.PlayerState.PLAYING;
              const now = Date.now();
              if (isPlaying) {
                ytWatchedTimeRef.current += (now - ytLastTickRef.current) / 1000;
              }
              ytLastTickRef.current = now;

              const watchedSec = Math.floor(ytWatchedTimeRef.current);
              setElapsedSeconds(watchedSec);
              const requiredSec = Math.ceil((d * requiredPercent) / 100);
              const progress = requiredSec > 0 ? Math.min(100, Math.floor((watchedSec / requiredSec) * 100)) : 0;
              setWatchProgress(progress);

              if (progress >= 100) {
                setVideoEnded(prev => {
                  if (!prev) return true;
                  return prev;
                });
              }
            }, 300);
          },
          onStateChange: (event: any) => {
            const state = event.data;
            const playing = state === (window as any).YT.PlayerState.PLAYING;
            setYtIsPlaying(playing);
            if (playing) {
              ytLastTickRef.current = Date.now();
            }
          },
        },
      });
    };

    let cancelled = false;
    const waitForYT = () => {
      if (cancelled) return;
      if ((window as any).YT && (window as any).YT.Player) {
        ytWaitTimerRef.current = setTimeout(createPlayer, 100);
      } else {
        ytWaitTimerRef.current = setTimeout(waitForYT, 200);
      }
    };
    waitForYT();

    return () => {
      cancelled = true;
      if (ytWaitTimerRef.current) {
        clearTimeout(ytWaitTimerRef.current);
        ytWaitTimerRef.current = null;
      }
      if (ytTimerRef.current) {
        clearInterval(ytTimerRef.current);
        ytTimerRef.current = null;
      }
      if (youtubePlayerRef.current) {
        try { youtubePlayerRef.current.destroy(); } catch {}
        youtubePlayerRef.current = null;
      }
    };
  }, [mode, watchingVideoId, videos]);

  // Start watching a video
  const startWatch = useCallback((videoId: string) => {
    setWatchingVideoId(videoId);
    setVideoEnded(false);
    setYtIsPlaying(false);
    setYtCurrentTime(0);
    setVideoDuration(0);
    setYtIsDragging(false);
  }, []);

  // Voice recording functions - tap to start/stop
  const toggleRecording = useCallback(async () => {
    if (isRecording) {
      // Stop recording
      if (mediaRecorderRef.current) {
        mediaRecorderRef.current.stop();
        setIsRecording(false);
        if (recordingIntervalRef.current) {
          clearInterval(recordingIntervalRef.current);
          recordingIntervalRef.current = null;
        }
      }
    } else {
      // Start recording - pause video first
      if (youtubePlayerRef.current && typeof youtubePlayerRef.current.pauseVideo === 'function') {
        youtubePlayerRef.current.pauseVideo();
      }
      
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        // Detect best supported audio format (iOS needs mp4/aac, others prefer webm)
        let mimeType = 'audio/webm';
        if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
        
        const mediaRecorder = new MediaRecorder(stream, { mimeType });
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];
        recordingStartTimeRef.current = Date.now();
        setLiveRecordingTime(0);
        
        // Start live timer
        recordingIntervalRef.current = setInterval(() => {
          setLiveRecordingTime(Math.round((Date.now() - recordingStartTimeRef.current) / 1000));
        }, 100);
        
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };
        
        mediaRecorder.onstop = () => {
          const duration = Math.round((Date.now() - recordingStartTimeRef.current) / 1000);
          setRecordingDuration(duration);
          stream.getTracks().forEach(track => track.stop());
          
          if (duration < 1) {
            setHasRecording(false);
            setAudioDataUrl(null);
            toast({ title: "Too short!", description: "Hold the record button a bit longer and try again.", variant: "destructive" });
            return;
          }
          
          setHasRecording(true);
          const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
          const reader = new FileReader();
          reader.onloadend = () => {
            setAudioDataUrl(reader.result as string);
          };
          reader.readAsDataURL(audioBlob);
        };
        
        mediaRecorder.start();
        setIsRecording(true);
      } catch (error) {
        toast({ title: "Microphone access needed", description: "Please allow microphone access to record your answer.", variant: "destructive" });
      }
    }
  }, [isRecording, toast]);

  // Complete a video (requires voice recording)
  const completeVideo = useCallback(() => {
    if (!videoEnded || !watchingVideoId || !activeKid || !hasRecording) return;
    
    const voiceRecording: VoiceRecording = {
      recordedAt: new Date().toISOString(),
      duration: recordingDuration,
      audioData: audioDataUrl || undefined,
    };
    
    markWatchedMutation.mutate({ videoId: watchingVideoId, kidId: activeKid.id, voiceRecording });
  }, [videoEnded, watchingVideoId, activeKid, markWatchedMutation, hasRecording, recordingDuration, audioDataUrl]);
  
  // Toggle kid selection for video assignment
  const toggleKidSelection = useCallback((kidId: string) => {
    setSelectedKidIds(prev => 
      prev.includes(kidId) ? prev.filter(id => id !== kidId) : [...prev, kidId]
    );
  }, []);

  // Cycle avatar
  const cycleAvatar = useCallback(() => {
    const idx = AVATARS.indexOf(newKidAvatar);
    setNewKidAvatar(AVATARS[(idx + 1) % AVATARS.length]);
  }, [newKidAvatar]);

  // Loading state
  if (kidsLoading || videosLoading || foldersLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50 dark:from-purple-950 dark:via-pink-950 dark:to-yellow-950">
        <div className="container mx-auto p-4 max-w-4xl">
          <div className="flex items-center justify-center gap-3 mb-8 pt-8">
            <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            <span className="text-xl font-semibold text-muted-foreground">Loading...</span>
          </div>
          <div className="space-y-4">
            <Skeleton className="h-40 w-full rounded-xl" />
            <Skeleton className="h-40 w-full rounded-xl" />
            <Skeleton className="h-60 w-full rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  // Render video player for kid mode
  if (mode === "kid" && watchingVideoId) {
    const watchingVideo = videos.find(v => v.id === watchingVideoId);
    if (!watchingVideo) return null;

    const avatarConfig = getAvatarConfig(activeKid?.avatar || "child");

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50 dark:from-purple-950 dark:via-pink-950 dark:to-yellow-950">
        <div className="container mx-auto p-4 max-w-4xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarConfig.color} flex items-center justify-center text-white shadow-lg`}>
                <AvatarIcon avatar={activeKid?.avatar || "child"} className="w-4 h-4" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-foreground">{activeKid?.name}'s Video</h1>
                <p className="text-xs text-muted-foreground">Watch until the end to complete!</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => { 
                setWatchingVideoId(null); 
                setVideoEnded(false); 
                setHasRecording(false);
                setAudioDataUrl(null);
                setRecordingDuration(0);
                setTiktokStarted(false);
                setWatchProgress(0);
                setYtIsPlaying(false);
                setYtCurrentTime(0);
                setVideoDuration(0);
                if (progressIntervalRef.current) {
                  clearInterval(progressIntervalRef.current);
                  progressIntervalRef.current = null;
                }
                if (ytTimerRef.current) {
                  clearInterval(ytTimerRef.current);
                  ytTimerRef.current = null;
                }
                if (youtubePlayerRef.current) {
                  try { youtubePlayerRef.current.destroy(); } catch {}
                  youtubePlayerRef.current = null;
                }
              }}
              data-testid="button-back"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </div>

          {/* Video Player */}
          <Card className="overflow-hidden">
            <div className={`relative bg-black ${watchingVideo.platform === "tiktok" ? "h-[70vh]" : "aspect-video"}`}>
{(() => {
                // Calculate required watch percentage based on view count
                const viewCount = watchingVideo.totalViews || 0;
                const isFirstWatch = viewCount === 0;
                const requiredPercent = isFirstWatch ? 90 : 60;
                
                // Estimated video duration for TikTok (YouTube uses real duration from API)
                const estimatedDuration = 45;
                const requiredSeconds = Math.ceil((estimatedDuration * requiredPercent) / 100);
                
                // Start progress tracking for TikTok
                const startProgressTracking = () => {
                  if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
                  const startTime = Date.now();
                  tiktokStartTimeRef.current = startTime;
                  videoStartTimeRef.current = startTime;
                  
                  progressIntervalRef.current = setInterval(() => {
                    const elapsed = Math.floor((Date.now() - startTime) / 1000);
                    setElapsedSeconds(elapsed);
                    const progress = Math.min(100, Math.floor((elapsed / requiredSeconds) * 100));
                    setWatchProgress(progress);
                    
                    if (progress >= 100 && !videoEnded) {
                      setVideoEnded(true);
                      if (progressIntervalRef.current) {
                        clearInterval(progressIntervalRef.current);
                      }
                    }
                  }, 1000);
                };
                
                return watchingVideo.platform === "tiktok" ? (
                  <>
                    {!tiktokStarted ? (
                      <button
                        className="absolute inset-0 z-10 bg-gradient-to-br from-pink-500 via-red-500 to-cyan-500 flex flex-col items-center justify-center cursor-pointer"
                        onClick={() => {
                          setTiktokStarted(true);
                          startProgressTracking();
                        }}
                        data-testid="button-tiktok-start"
                      >
                        <div className="bg-white/20 backdrop-blur-sm rounded-full p-6 mb-4">
                          <Play className="w-16 h-16 text-white" />
                        </div>
                        <p className="text-white text-xl font-bold mb-2">Tap to Play with Sound</p>
                        <div className="flex items-center gap-2 text-white/80">
                          <Volume2 className="w-5 h-5" />
                          <span>Sound will be ON</span>
                        </div>
                        <p className="text-white/60 text-sm mt-2">
                          {isFirstWatch ? `Watch ${requiredPercent}% to complete` : `Re-watch: ${requiredPercent}% needed`}
                        </p>
                      </button>
                    ) : (
                        <iframe
                          width="100%"
                          height="100%"
                          src={`https://www.tiktok.com/embed/v2/${watchingVideo.ytId}?autoplay=1`}
                          title="TikTok video player"
                          frameBorder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                          allowFullScreen
                          style={{ pointerEvents: videoEnded ? 'none' : 'auto' }}
                        />
                    )}
                    {tiktokStarted && !videoEnded && (
                      <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-white text-xs p-2 pointer-events-none">
                        <div className="flex items-center gap-2 mb-1">
                          <span>Watching: {watchProgress}%</span>
                          <span className="text-white/60">({isFirstWatch ? '90%' : '60%'} needed)</span>
                        </div>
                        <div className="w-full bg-white/30 rounded-full h-1">
                          <div 
                            className="bg-gradient-to-r from-purple-500 to-pink-500 h-1 rounded-full transition-all duration-300"
                            style={{ width: `${watchProgress}%` }}
                          />
                        </div>
                      </div>
                    )}
                    {videoEnded && hasRecording && (
                      <div 
                        className="absolute inset-0 bg-black/50 flex items-center justify-center"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="text-center text-white p-4">
                          <CheckCircle className="w-12 h-12 mx-auto mb-2 text-green-400" />
                          <p className="text-lg font-bold">All Done!</p>
                          <p className="text-sm opacity-80">Tap Complete Video below</p>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <>
                    <div ref={youtubePlayerContainerRef} className="w-full h-full" />
                    {/* Custom Controls Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 z-10">
                      {/* Watch progress bar */}
                      {!videoEnded && (
                        <div className="px-3 pb-1 pointer-events-none">
                          <div className="flex items-center gap-2 mb-1 text-white text-xs">
                            <span>Watching: {watchProgress}%</span>
                            <span className="text-white/60">({isFirstWatch ? '90%' : '60%'} needed)</span>
                          </div>
                          <div className="w-full bg-white/30 rounded-full h-1">
                            <div 
                              className="bg-gradient-to-r from-purple-500 to-pink-500 h-1 rounded-full transition-all duration-300"
                              style={{ width: `${watchProgress}%` }}
                            />
                          </div>
                        </div>
                      )}
                      {/* Scrub bar */}
                      <div className="px-3 pt-1">
                        <input
                          type="range"
                          min={0}
                          max={1000}
                          value={ytIsDragging ? ytDragValue : (videoDuration > 0 ? Math.round((ytCurrentTime / videoDuration) * 1000) : 0)}
                          onInput={(e) => {
                            setYtIsDragging(true);
                            setYtDragValue(Number((e.target as HTMLInputElement).value));
                          }}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            const pct = val / 1000;
                            const seekTime = videoDuration * pct;
                            if (youtubePlayerRef.current && typeof youtubePlayerRef.current.seekTo === 'function') {
                              youtubePlayerRef.current.seekTo(seekTime, true);
                            }
                            setYtIsDragging(false);
                          }}
                          className="w-full h-1 appearance-none bg-white/30 rounded-full cursor-pointer accent-purple-500"
                          style={{ accentColor: '#a855f7' }}
                          data-testid="input-scrub-bar"
                        />
                      </div>
                      {/* Control buttons */}
                      <div className="flex items-center justify-between px-3 py-2 bg-black/70">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => {
                              const p = youtubePlayerRef.current;
                              if (!p) return;
                              const cur = p.getCurrentTime() || 0;
                              p.seekTo(Math.max(0, cur - 10), true);
                            }}
                            className="text-white p-1"
                            data-testid="button-rewind-10s"
                          >
                            <RotateCcw className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => {
                              const p = youtubePlayerRef.current;
                              if (!p) return;
                              if (ytIsPlaying) {
                                p.pauseVideo();
                              } else {
                                p.playVideo();
                              }
                            }}
                            className="text-white bg-white/20 rounded-full p-2"
                            data-testid="button-play-pause"
                          >
                            {ytIsPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                          </button>
                          <button
                            onClick={() => {
                              const p = youtubePlayerRef.current;
                              if (!p) return;
                              const cur = p.getCurrentTime() || 0;
                              const dur = p.getDuration() || 0;
                              p.seekTo(Math.min(dur, cur + 10), true);
                            }}
                            className="text-white p-1"
                            data-testid="button-ff-10s"
                          >
                            <SkipForward className="w-5 h-5" />
                          </button>
                        </div>
                        <div className="text-white text-xs font-mono" data-testid="text-video-time">
                          {(() => {
                            const fmt = (s: number) => {
                              s = Math.max(0, Math.floor(s));
                              const m = Math.floor(s / 60);
                              const sec = s % 60;
                              return `${m}:${String(sec).padStart(2, '0')}`;
                            };
                            return `${fmt(ytCurrentTime)} / ${fmt(videoDuration)}`;
                          })()}
                        </div>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
            <CardContent className="p-4">
              <div className="space-y-3">
                {!videoEnded ? (
                  <div className="flex items-center gap-2 text-muted-foreground" data-testid="step-watch-video">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <p className="text-sm">Watch the video until the end...</p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 text-green-600 dark:text-green-400" data-testid="step-video-complete">
                      <CheckCircle className="w-5 h-5" />
                      <p className="text-sm font-medium">Video watched!</p>
                    </div>
                    
                    {/* Optional recording section */}
                    {isRecording ? (
                      <div className="p-4 bg-red-50 dark:bg-red-950 rounded-lg border-2 border-red-300 dark:border-red-700" data-testid="step-voice-recording">
                        <div className="flex flex-col items-center gap-3">
                          <div className="flex items-center gap-3">
                            <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse" />
                            <span className="text-3xl font-bold text-red-600 dark:text-red-400 tabular-nums" data-testid="text-recording-timer">
                              {liveRecordingTime}s
                            </span>
                          </div>
                          <p className="text-sm text-red-600 dark:text-red-400 font-medium">Recording... Tell us what you learned!</p>
                          <Button
                            size="lg"
                            variant="destructive"
                            className="w-full"
                            onClick={toggleRecording}
                            data-testid="button-stop-record"
                          >
                            <Square className="w-5 h-5 mr-2" />
                            Stop Recording
                          </Button>
                        </div>
                      </div>
                    ) : !hasRecording ? (
                      <div className="p-3 bg-purple-50 dark:bg-purple-950 rounded-lg" data-testid="step-voice-recording">
                        <div className="flex items-center gap-3">
                          <div className="flex-1">
                            <p className="text-sm font-medium">Want to record a message?</p>
                            <p className="text-xs text-muted-foreground">Tap to tell us what you learned (optional)</p>
                          </div>
                          <Button
                            size="lg"
                            variant="default"
                            onClick={toggleRecording}
                            data-testid="button-record"
                          >
                            <Mic className="w-5 h-5 mr-2" />
                            Record
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950 rounded-lg" data-testid="step-recording-saved">
                        <Mic className="w-4 h-4 text-green-600 dark:text-green-400" />
                        <p className="text-sm text-green-600 dark:text-green-400 flex-1">Recording saved ({recordingDuration}s)</p>
                        <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setHasRecording(false);
                            setRecordingDuration(0);
                            setAudioDataUrl(null);
                          }}
                          data-testid="button-re-record"
                        >
                          <RotateCcw className="w-3 h-3 mr-1" />
                          Redo
                        </Button>
                      </div>
                    )}

                    {/* Complete button - always enabled after video ends */}
                    <Button
                      variant="default"
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500"
                      disabled={markWatchedMutation.isPending}
                      onClick={completeVideo}
                      data-testid="button-complete"
                    >
                      {markWatchedMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Star className="w-4 h-4 mr-2" />
                          Complete Video!
                        </>
                      )}
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Kid mode - playlist view
  if (mode === "kid") {
    const stats = getKidStats(activeKid?.id || "");
    const avatarConfig = getAvatarConfig(activeKid?.avatar || "child");
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50 dark:from-purple-950 dark:via-pink-950 dark:to-yellow-950">
        <div className="container mx-auto p-4 max-w-4xl">
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2">
              <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${avatarConfig.color} flex items-center justify-center text-white shadow-lg`}>
                <AvatarIcon avatar={activeKid?.avatar || "child"} className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  {activeKid?.name}'s Videos
                </h1>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    {stats.watched} watched
                  </Badge>
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300">
                    <Play className="w-3 h-3 mr-1" />
                    {stats.pending} pending
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {/* Add to Home Screen button - show if not already installed as PWA */}
              {!isStandalone && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleInstallClick}
                  data-testid="button-add-home-screen"
                >
                  <Download className="w-4 h-4 mr-1" />
                  Add to Home
                </Button>
              )}
              {isLockedKidMode ? (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    localStorage.removeItem('lockedKidId');
                    window.location.href = '/';
                  }}
                  data-testid="button-exit-kid-mode"
                >
                  <LogOut className="w-4 h-4 mr-1" />
                  Exit
                </Button>
              ) : (
                <Button
                  variant="outline"
                  onClick={() => setMode("parent")}
                  data-testid="button-parent-mode"
                >
                  <User className="w-4 h-4 mr-2" />
                  Parent Mode
                </Button>
              )}
            </div>
          </div>

          {/* Kid Selector - only show if not locked to specific kid */}
          {!isLockedKidMode && (
          <Card className="mb-4">
            <CardContent className="p-3">
              <p className="text-xs font-medium text-muted-foreground mb-2">Who's watching?</p>
              <div className="flex flex-wrap gap-1">
                {kids.map(k => {
                  const config = getAvatarConfig(k.avatar);
                  return (
                    <Button
                      key={k.id}
                      size="sm"
                      variant={activeKidId === k.id ? "default" : "outline"}
                      onClick={() => setActiveKidId(k.id)}
                      className={activeKidId === k.id ? `bg-gradient-to-r ${config.color}` : ""}
                      data-testid={`button-kid-${k.id}`}
                    >
                      <AvatarIcon avatar={k.avatar} className="w-4 h-4 mr-1" />
                      {k.name}
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
          )}

          {/* Video List - Organized by Folders */}
          <div className="space-y-4">
            {assignedVideos.length === 0 ? (
              <Card className="p-6 text-center">
                <div className="w-14 h-14 mx-auto mb-3 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                  <Video className="w-7 h-7 text-purple-500" />
                </div>
                <h3 className="text-base font-semibold mb-1">No videos yet!</h3>
                <p className="text-sm text-muted-foreground">
                  Ask a parent to add some fun videos for you!
                </p>
              </Card>
            ) : (
              kidVideosByFolder.map(group => (
                <Card key={group.id} className="overflow-hidden" data-testid={`kid-folder-${group.id}`}>
                  {/* Folder Header */}
                  <button
                    onClick={() => {
                      const newExpanded = new Set(expandedFolders);
                      if (newExpanded.has(group.id)) {
                        newExpanded.delete(group.id);
                      } else {
                        newExpanded.add(group.id);
                      }
                      setExpandedFolders(newExpanded);
                    }}
                    className="w-full flex items-center gap-3 p-3 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/50 dark:to-pink-900/50 text-left"
                    data-testid={`button-kid-folder-${group.id}`}
                  >
                    {expandedFolders.has(group.id) ? (
                      <ChevronDown className="w-5 h-5 text-purple-500" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-purple-500" />
                    )}
                    <FolderIcon className="w-5 h-5 text-purple-500" />
                    <span className="font-semibold text-purple-700 dark:text-purple-300">{group.name}</span>
                    <Badge variant="secondary" className="ml-auto bg-purple-200 dark:bg-purple-800">
                      {group.videos.length} video{group.videos.length !== 1 ? 's' : ''}
                    </Badge>
                  </button>
                  
                  {/* Videos in Folder */}
                  {expandedFolders.has(group.id) && (
                    <div className="divide-y">
                      {group.videos.map(video => {
                        const isWatched = video.progress?.[activeKid?.id]?.watched;
                        const viewCount = video.totalViews || 0;
                        const isMaxed = viewCount >= MAX_VIDEO_VIEWS;
                        const isLocked = !isWatched && isVideoLocked(video, group.videos, activeKid?.id || "");
                        const canWatch = !isMaxed && !isLocked;
                        const canRewatch = isWatched && !isMaxed;
                        const priority = video.priority || 5;
                        
                        return (
                          <div 
                            key={video.id} 
                            className={`flex flex-row items-stretch gap-2 ${isWatched ? 'opacity-75' : isMaxed || isLocked ? 'opacity-60' : ''}`}
                          >
                            {/* Thumbnail - full row height */}
                            <div className="relative w-20 min-h-[4rem] bg-gradient-to-br from-purple-200 to-pink-200 dark:from-purple-800 dark:to-pink-800 flex items-center justify-center shrink-0">
                              {video.platform === "tiktok" ? (
                                <TikTokThumbnail videoId={video.ytId} className="w-full h-full" />
                              ) : (
                                <img
                                  src={`https://img.youtube.com/vi/${video.ytId}/mqdefault.jpg`}
                                  alt="Video thumbnail"
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    e.currentTarget.style.display = 'none';
                                  }}
                                />
                              )}
                              {isWatched && (
                                <div className="absolute inset-0 bg-green-500/80 flex items-center justify-center">
                                  <CheckCircle className="w-5 h-5 text-white" />
                                </div>
                              )}
                              {!isWatched && isMaxed && (
                                <div className="absolute inset-0 bg-red-500/80 flex items-center justify-center">
                                  <AlertTriangle className="w-5 h-5 text-white" />
                                </div>
                              )}
                              {!isWatched && !isMaxed && isLocked && (
                                <div className="absolute inset-0 bg-gray-500/80 flex items-center justify-center">
                                  <Lock className="w-5 h-5 text-white" />
                                </div>
                              )}
                            </div>
                            {/* Content - compact */}
                            <div className="flex-1 min-w-0 py-2">
                              <div className="flex items-center gap-1 mb-1 flex-wrap">
                                {video.platform === "tiktok" ? (
                                  <SiTiktok className="w-3 h-3 shrink-0" />
                                ) : (
                                  <Youtube className="w-3 h-3 text-red-500 shrink-0" />
                                )}
                                <span className="text-xs text-muted-foreground font-mono truncate max-w-[100px]">{video.ytId}</span>
                                <Badge variant="outline" className="text-xs" data-testid={`badge-priority-${video.id}`}>
                                  Lv.{priority}
                                </Badge>
                              </div>
                              <div className="flex flex-wrap items-center gap-1">
                                {isWatched ? (
                                  <Badge className="bg-green-500 text-white text-xs" data-testid={`badge-status-${video.id}`}>
                                    <CheckCircle className="w-3 h-3 mr-0.5" />
                                    Done
                                  </Badge>
                                ) : isLocked ? (
                                  <Badge variant="secondary" className="text-xs bg-gray-200 dark:bg-gray-700" data-testid={`badge-status-${video.id}`}>
                                    <Lock className="w-3 h-3 mr-0.5" />
                                    Locked
                                  </Badge>
                                ) : isMaxed ? (
                                  <Badge variant="destructive" className="text-xs" data-testid={`badge-status-${video.id}`}>
                                    <AlertTriangle className="w-3 h-3 mr-0.5" />
                                    Max
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary" className="text-xs" data-testid={`badge-status-${video.id}`}>
                                    <Sparkles className="w-3 h-3 mr-0.5" />
                                    Ready
                                  </Badge>
                                )}
                                <Badge variant="outline" className="text-xs" data-testid={`badge-views-kid-${video.id}`}>
                                  <Eye className="w-2 h-2 mr-0.5" />
                                  {viewCount}/{MAX_VIDEO_VIEWS}
                                </Badge>
                              </div>
                            </div>
                            {/* Watch button */}
                            <div className="flex items-center pr-2">
                              {canWatch && (
                                <Button
                                  size="sm"
                                  onClick={() => startWatch(video.id)}
                                  className={`shrink-0 ${canRewatch ? "bg-gradient-to-r from-green-500 to-teal-500" : "bg-gradient-to-r from-purple-500 to-pink-500"}`}
                                  data-testid={`button-watch-${video.id}`}
                                >
                                  <Play className="w-4 h-4 mr-1" />
                                  {canRewatch ? "Again" : "Watch"}
                                </Button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </Card>
              ))
            )}
          </div>
          
          {/* Add to Home Screen Instructions Dialog */}
          <Dialog open={showHomeScreenInstructions} onOpenChange={setShowHomeScreenInstructions}>
            <DialogContent className="max-w-sm">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Download className="w-5 h-5" />
                  Add to Home Screen
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                {isIOS ? (
                  <>
                    <p className="text-sm text-muted-foreground">
                      To add {activeKid?.name}'s video app to your home screen:
                    </p>
                    <ol className="text-sm space-y-3">
                      <li className="flex items-start gap-2">
                        <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">1</span>
                        <span>Tap the <strong>Share button</strong> at the bottom of Safari (square with arrow pointing up)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">2</span>
                        <span>Scroll down and tap <strong>"Add to Home Screen"</strong></span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">3</span>
                        <span>Tap <strong>"Add"</strong> in the top right corner</span>
                      </li>
                    </ol>
                    <p className="text-xs text-muted-foreground bg-muted p-2 rounded">
                      The app will open directly to {activeKid?.name}'s videos every time!
                    </p>
                  </>
                ) : isAndroid ? (
                  <>
                    <p className="text-sm text-muted-foreground">
                      To add {activeKid?.name}'s video app to your home screen:
                    </p>
                    <ol className="text-sm space-y-3">
                      <li className="flex items-start gap-2">
                        <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">1</span>
                        <span>Tap the <strong>menu button</strong> (three dots) in Chrome</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">2</span>
                        <span>Tap <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong></span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">3</span>
                        <span>Tap <strong>"Add"</strong> to confirm</span>
                      </li>
                    </ol>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Use your browser's menu to add this page to your home screen or bookmarks.
                  </p>
                )}
              </div>
              <a 
                href="/api/download-icon"
                download="kid-video-app-icon.png"
                className="block"
              >
                <Button 
                  variant="outline"
                  className="w-full mt-2"
                  data-testid="button-download-icon"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download App Icon
                </Button>
              </a>
              <Button 
                onClick={() => setShowHomeScreenInstructions(false)} 
                className="w-full mt-2"
                data-testid="button-close-home-instructions"
              >
                Got it!
              </Button>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    );
  }

  // Parent mode
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 dark:from-purple-950 dark:via-blue-950 dark:to-cyan-950">
      <div className="container mx-auto p-4 max-w-4xl">
        {/* Header */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-500" />
              Kid Video App
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {/* Feedback Button */}
            <Dialog open={feedbackOpen} onOpenChange={(open) => { setFeedbackOpen(open); if (!open) resetFeedbackForm(); }}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" data-testid="button-feedback">
                  <MessageSquare className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Send Feedback
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Feedback Type Selector */}
                  <div className="flex gap-2 flex-wrap">
                    <Button
                      variant={feedbackType === 'text' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFeedbackType('text')}
                      data-testid="button-feedback-type-text"
                    >
                      <Pencil className="w-3 h-3 mr-1" />
                      Text
                    </Button>
                    <Button
                      variant={feedbackType === 'voice' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFeedbackType('voice')}
                      data-testid="button-feedback-type-voice"
                    >
                      <Mic className="w-3 h-3 mr-1" />
                      Voice
                    </Button>
                    <Button
                      variant={feedbackType === 'video' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFeedbackType('video')}
                      data-testid="button-feedback-type-video"
                    >
                      <Video className="w-3 h-3 mr-1" />
                      Video Link
                    </Button>
                    <Button
                      variant={feedbackType === 'screenshot' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFeedbackType('screenshot')}
                      data-testid="button-feedback-type-screenshot"
                    >
                      <Image className="w-3 h-3 mr-1" />
                      Screenshot
                    </Button>
                  </div>

                  {/* Feedback Input Based on Type */}
                  {feedbackType === 'text' && (
                    <Textarea
                      placeholder="Tell us what you think, report bugs, or share ideas..."
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      className="min-h-[100px]"
                      data-testid="input-feedback-text"
                    />
                  )}

                  {feedbackType === 'voice' && (
                    <div className="flex flex-col items-center gap-4 py-4">
                      {feedbackAudioData ? (
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const audio = new Audio(feedbackAudioData);
                              audio.play();
                            }}
                            data-testid="button-play-feedback-audio"
                          >
                            <Volume2 className="w-4 h-4 mr-1" />
                            Play ({feedbackAudioDuration}s)
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => { setFeedbackAudioData(null); setFeedbackAudioDuration(0); }}
                          >
                            <RotateCcw className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <Button
                          size="lg"
                          variant={feedbackRecording ? "destructive" : "default"}
                          className="rounded-full w-16 h-16"
                          onMouseDown={startFeedbackRecording}
                          onMouseUp={stopFeedbackRecording}
                          onTouchStart={startFeedbackRecording}
                          onTouchEnd={stopFeedbackRecording}
                          data-testid="button-feedback-record"
                        >
                          {feedbackRecording ? (
                            <div className="flex flex-col items-center">
                              <Square className="w-5 h-5" />
                              <span className="text-xs">{feedbackLiveTime}s</span>
                            </div>
                          ) : (
                            <Mic className="w-6 h-6" />
                          )}
                        </Button>
                      )}
                      <p className="text-xs text-muted-foreground text-center">
                        {feedbackRecording ? "Recording... Release to stop" : feedbackAudioData ? "Recording saved" : "Hold to record"}
                      </p>
                    </div>
                  )}

                  {feedbackType === 'video' && (
                    <Input
                      placeholder="Paste YouTube or TikTok video link..."
                      value={feedbackVideoUrl}
                      onChange={(e) => setFeedbackVideoUrl(e.target.value)}
                      data-testid="input-feedback-video"
                    />
                  )}

                  {feedbackType === 'screenshot' && (
                    <div className="space-y-2">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleScreenshotUpload}
                        className="hidden"
                        id="screenshot-upload"
                        data-testid="input-feedback-screenshot"
                      />
                      <label
                        htmlFor="screenshot-upload"
                        className="flex flex-col items-center gap-2 p-6 border-2 border-dashed rounded-lg cursor-pointer hover:border-primary/50 transition-colors"
                      >
                        {feedbackScreenshot ? (
                          <img src={feedbackScreenshot} alt="Screenshot" className="max-h-40 rounded" />
                        ) : (
                          <>
                            <Camera className="w-8 h-8 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">Click to upload screenshot</span>
                          </>
                        )}
                      </label>
                    </div>
                  )}

                  {/* Submit Button */}
                  <Button
                    className="w-full"
                    onClick={submitFeedback}
                    disabled={feedbackMutation.isPending}
                    data-testid="button-submit-feedback"
                  >
                    {feedbackMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Send Feedback
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {/* Settings Button */}
            <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" data-testid="button-settings">
                  <Settings className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Manage Kids ({kids.length}/6)
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Add Kid Form */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Kid's name"
                      value={newKidName}
                      onChange={e => setNewKidName(e.target.value)}
                      className="flex-1 text-sm"
                      data-testid="input-kid-name"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={cycleAvatar}
                      className={`bg-gradient-to-br ${getAvatarConfig(newKidAvatar).color} text-white border-0`}
                      data-testid="button-cycle-avatar"
                    >
                      <AvatarIcon avatar={newKidAvatar} className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm"
                      onClick={addKid} 
                      disabled={createKidMutation.isPending || kids.length >= 6}
                      data-testid="button-add-kid"
                    >
                      {createKidMutation.isPending ? (
                        <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                      ) : (
                        <Plus className="w-3 h-3 mr-1" />
                      )}
                      Add
                    </Button>
                  </div>
                  
                  {/* Kids List */}
                  {kids.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-2">No kids added yet.</p>
                  ) : (
                    <div className="space-y-2">
                      {kids.map(kid => {
                        const stats = getKidStats(kid.id);
                        const avatarConfig = getAvatarConfig(kid.avatar);
                        const isEditing = editingKidId === kid.id;
                        return (
                          <div
                            key={kid.id}
                            className="flex items-center gap-2 p-2 rounded-lg bg-muted/50"
                          >
                            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarConfig.color} flex items-center justify-center text-white shrink-0`}>
                              <AvatarIcon avatar={kid.avatar} className="w-4 h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              {isEditing ? (
                                <div className="flex items-center gap-1">
                                  <Input
                                    value={editingKidName}
                                    onChange={e => setEditingKidName(e.target.value)}
                                    className="h-7 text-sm"
                                    data-testid={`input-edit-kid-${kid.id}`}
                                    autoFocus
                                  />
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-7 w-7"
                                    onClick={() => {
                                      if (editingKidName.trim()) {
                                        updateKidMutation.mutate({ id: kid.id, name: editingKidName.trim() });
                                      }
                                    }}
                                    disabled={updateKidMutation.isPending}
                                    data-testid={`button-save-kid-${kid.id}`}
                                  >
                                    <Check className="w-3 h-3" />
                                  </Button>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-7 w-7"
                                    onClick={() => { setEditingKidId(null); setEditingKidName(""); }}
                                    data-testid={`button-cancel-edit-${kid.id}`}
                                  >
                                    <X className="w-3 h-3" />
                                  </Button>
                                </div>
                              ) : (
                                <>
                                  <p className="text-sm font-semibold truncate">{kid.name}</p>
                                  <div className="flex items-center gap-1">
                                    <Badge variant="outline" className="text-xs">
                                      <CheckCircle className="w-2 h-2 mr-1 text-green-500" />
                                      {stats.watched} watched
                                    </Badge>
                                    <Badge variant="outline" className="text-xs">
                                      <Play className="w-2 h-2 mr-1 text-yellow-500" />
                                      {stats.pending} pending
                                    </Badge>
                                  </div>
                                </>
                              )}
                            </div>
                            {!isEditing && (
                              <div className="flex items-center gap-1 shrink-0">
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-7 w-7"
                                  onClick={() => {
                                    const link = `${window.location.origin}/kid/${kid.id}`;
                                    navigator.clipboard.writeText(link);
                                    toast({ 
                                      title: `Link copied for ${kid.name}!`, 
                                      description: "Open this link in Safari/Chrome, tap Share, then 'Add to Home Screen' to create an app icon." 
                                    });
                                  }}
                                  data-testid={`button-copy-link-${kid.id}`}
                                  title="Copy link for home screen shortcut"
                                >
                                  <Download className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-7 w-7"
                                  onClick={() => { setEditingKidId(kid.id); setEditingKidName(kid.name); }}
                                  data-testid={`button-edit-kid-${kid.id}`}
                                >
                                  <Pencil className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-7 w-7 text-destructive"
                                  onClick={() => deleteKidMutation.mutate(kid.id)}
                                  disabled={deleteKidMutation.isPending}
                                  data-testid={`button-delete-kid-${kid.id}`}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  
                  {/* Add to Home Screen instructions */}
                  {kids.length > 0 && (
                    <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800">
                      <div className="flex items-center gap-2 mb-2">
                        <Download className="w-4 h-4 text-purple-600" />
                        <p className="text-sm font-semibold text-purple-800 dark:text-purple-200">Add Kid Shortcuts to Home Screen</p>
                      </div>
                      <p className="text-xs text-purple-700 dark:text-purple-300">
                        Tap the <Download className="w-3 h-3 inline" /> button next to a kid's name to copy their personal link. 
                        Then open the link in Safari (iPhone) or Chrome (Android), tap Share, and select "Add to Home Screen". 
                        The shortcut will open directly to that kid's videos!
                      </p>
                    </div>
                  )}

                  {/* Account ID */}
                  {user?.id && (
                    <p className="text-xs text-muted-foreground text-center pt-2 border-t" data-testid="text-account-id">
                      Account ID: {user.id}
                    </p>
                  )}
                </div>
              </DialogContent>
            </Dialog>

            {/* Logout Button */}
            <Button
              variant="outline"
              size="icon"
              asChild
              data-testid="button-logout"
            >
              <a href="/api/logout">
                <LogOut className="w-4 h-4" />
              </a>
            </Button>

            <Button
              size="sm"
              onClick={() => setMode("kid")}
              className="bg-gradient-to-r from-purple-500 to-pink-500"
              data-testid="button-kid-mode"
            >
              <Play className="w-4 h-4 mr-1" />
              Kid Mode
            </Button>
          </div>
        </div>
        
        {/* Kids row with stats + add kid inline */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          {kids.map(kid => {
            const stats = getKidStats(kid.id);
            const avatarConfig = getAvatarConfig(kid.avatar);
            return (
              <Badge 
                key={kid.id} 
                variant="secondary" 
                className="text-xs py-1 cursor-pointer" 
                onClick={() => setActivityStatsKidId(kid.id)}
                data-testid={`badge-kid-stats-${kid.id}`}
              >
                <div className={`w-4 h-4 rounded-full bg-gradient-to-br ${avatarConfig.color} flex items-center justify-center text-white mr-1`}>
                  <AvatarIcon avatar={kid.avatar} className="w-2 h-2" />
                </div>
                {kid.name}: {stats.watched}/{stats.total}
              </Badge>
            );
          })}
          {kids.length < 6 && (
            <div className="flex items-center gap-1">
              <Input
                placeholder="Kid name"
                value={newKidName}
                onChange={e => setNewKidName(e.target.value)}
                className="h-8 w-24 text-xs"
                data-testid="input-kid-name-inline"
              />
              <Button
                size="sm"
                variant="secondary"
                className="h-8"
                onClick={addKid}
                disabled={createKidMutation.isPending || kids.length >= 6}
                data-testid="button-add-kid-inline"
              >
                {createKidMutation.isPending ? (
                  <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                ) : (
                  <Plus className="w-3 h-3 mr-1" />
                )}
                Kid
              </Button>
            </div>
          )}
        </div>

        {/* Global Playlists Section with inline trial badge */}
        {globalPlaylists.length > 0 && (
          <Card className="mb-4">
            <CardHeader className="pb-2 pt-3 px-3">
              <CardTitle className="text-sm flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <Globe className="w-4 h-4 text-blue-500 shrink-0" />
                  <span className="truncate">Curated Playlists</span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {trialStatus?.show && (
                    <Badge variant="secondary" className="text-xs gap-1" data-testid="badge-trial-status">
                      <Gift className="w-3 h-3 text-amber-500" />
                      {trialStatus.frozen
                        ? "FREE"
                        : `FREE \u2022 ${trialStatus.daysLeft} days left`}
                    </Badge>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowGlobalPlaylists(!showGlobalPlaylists)}
                    data-testid="button-toggle-global-playlists"
                  >
                    {showGlobalPlaylists ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                  </Button>
                </div>
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1" data-testid="text-trial-subtext">
                Personal playlists are always free.
              </p>
            </CardHeader>
            {showGlobalPlaylists && (
              <CardContent className="pt-0 px-3 pb-3">
                <div className="space-y-2">
                  {globalPlaylists.map(gp => {
                    const isSubscribed = globalSubscriptions.some(s => s.masterFolderId === gp.id);
                    return (
                      <div key={gp.id} className="flex items-center justify-between gap-2 p-2 border rounded-md" data-testid={`global-playlist-${gp.id}`}>
                        <div className="flex items-center gap-2 min-w-0">
                          <FolderIcon className="w-4 h-4 text-blue-500 shrink-0" />
                          <span className="text-sm font-medium truncate">{gp.name}</span>
                          <Badge variant="secondary" className="text-xs shrink-0">{gp.videoCount} videos</Badge>
                        </div>
                        {isMaster ? (
                          <Badge variant="outline" className="text-xs shrink-0" data-testid={`badge-your-playlist-${gp.id}`}>
                            Yours
                          </Badge>
                        ) : (
                          <Button
                            size="sm"
                            variant={isSubscribed ? "outline" : "secondary"}
                            onClick={() => {
                              if (isSubscribed) {
                                unsubscribeMutation.mutate({ masterFolderId: gp.id });
                              } else {
                                subscribeMutation.mutate({ masterFolderId: gp.id, kidIds: [] });
                              }
                            }}
                            disabled={subscribeMutation.isPending || unsubscribeMutation.isPending}
                            data-testid={`button-subscribe-${gp.id}`}
                          >
                            {isSubscribed ? "Remove" : "Add"}
                          </Button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            )}
          </Card>
        )}

        {/* Add Video Card - compact merged layout */}
        <Card className="mb-4">
          <CardHeader className="pb-1 pt-3 px-3">
            <CardTitle className="flex items-center justify-between gap-2 text-sm">
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-purple-500" />
                Add Video
              </div>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => setIsFolderEditMode(!isFolderEditMode)}
                data-testid="button-toggle-folder-edit"
              >
                <FolderPlus className="w-3 h-3 mr-1" />
                Playlist
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 px-3 pb-3 space-y-2">
            {/* Folder selection */}
            <div className="flex flex-wrap gap-1">
              <Button
                variant={selectedFolderId === "unfiled" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFolderId(selectedFolderId === "unfiled" ? null : "unfiled")}
                data-testid="button-folder-none"
              >
                <FolderIcon className="w-3 h-3 mr-1" />
                Unfiled
              </Button>
              {folders.filter(f => !f.name.startsWith("__global_")).map(folder => (
                <div key={folder.id} className="flex items-center gap-0.5">
                  {editingFolderId === folder.id ? (
                    <div className="flex items-center gap-1">
                      <Input
                        value={editingFolderName}
                        onChange={e => setEditingFolderName(e.target.value)}
                        className="h-8 w-32 text-sm"
                        autoFocus
                        onKeyDown={e => {
                          if (e.key === "Enter") saveEditingFolder();
                          if (e.key === "Escape") cancelEditingFolder();
                        }}
                        data-testid={`input-edit-folder-${folder.id}`}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={saveEditingFolder}
                        disabled={updateFolderMutation.isPending}
                        data-testid={`button-save-folder-${folder.id}`}
                      >
                        <Check className="w-3 h-3 text-green-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={cancelEditingFolder}
                        data-testid={`button-cancel-edit-folder-${folder.id}`}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Button
                        variant={selectedFolderId === folder.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedFolderId(selectedFolderId === folder.id ? null : folder.id)}
                        data-testid={`button-folder-${folder.id}`}
                      >
                        {isMaster ? (
                          <Globe className="w-3 h-3 mr-1 text-blue-500" />
                        ) : (
                          <FolderIcon className="w-3 h-3 mr-1" />
                        )}
                        {folder.name}
                      </Button>
                      {isFolderEditMode && (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => startEditingFolder(folder)}
                            data-testid={`button-edit-folder-${folder.id}`}
                          >
                            <Pencil className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => setDeletingFolderId(folder.id)}
                            disabled={deleteFolderMutation.isPending}
                            data-testid={`button-delete-folder-${folder.id}`}
                          >
                            <Trash2 className="w-3 h-3 text-destructive" />
                          </Button>
                        </>
                      )}
                    </>
                  )}
                </div>
              ))}
              {isFolderEditMode && (
                <div className="flex gap-1 items-center">
                  <Input
                    placeholder="New playlist"
                    value={newFolderName}
                    onChange={e => setNewFolderName(e.target.value)}
                    className="h-8 w-28 text-xs"
                    data-testid="input-folder-name"
                  />
                  <Button 
                    size="sm"
                    className="h-8"
                    onClick={addFolder} 
                    disabled={createFolderMutation.isPending}
                    data-testid="button-add-folder"
                  >
                    {createFolderMutation.isPending ? (
                      <Loader2 className="w-3 h-3" />
                    ) : (
                      <FolderPlus className="w-3 h-3" />
                    )}
                  </Button>
                </div>
              )}
            </div>

            {/* URL input */}
            <div className="flex gap-1">
              <Input
                placeholder="Paste YouTube or TikTok link"
                value={videoUrl}
                onChange={e => setVideoUrl(e.target.value)}
                className="flex-1 text-sm"
                data-testid="input-video-url"
              />
              <Button 
                size="icon"
                variant="outline"
                onClick={pasteFromClipboard}
                title="Paste from clipboard"
                data-testid="button-paste-url"
              >
                <Clipboard className="w-4 h-4" />
              </Button>
            </div>
            
            {/* Priority Selection */}
            <div className="flex items-center gap-1">
              <span className="text-xs font-medium whitespace-nowrap">Lv:</span>
              <div className="flex flex-1 gap-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(level => (
                  <Button
                    key={level}
                    variant={videoPriority === level ? "default" : "outline"}
                    size="sm"
                    className={`flex-1 h-8 p-0 text-xs ${videoPriority === level ? 'bg-purple-500' : ''}`}
                    onClick={() => setVideoPriority(videoPriority === level ? null : level)}
                    data-testid={`priority-${level}`}
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Kid Selection */}
            <div className="flex items-center gap-2 flex-wrap">
              <Checkbox 
                id="assign-all"
                checked={assignToAll}
                onCheckedChange={(checked) => {
                  setAssignToAll(checked === true);
                  if (checked) setSelectedKidIds([]);
                }}
                data-testid="checkbox-all-kids"
              />
              <label htmlFor="assign-all" className="text-xs cursor-pointer">
                All Kids
              </label>
              {!assignToAll && kids.length > 0 && (
                <>
                  {kids.map(kid => {
                    const config = getAvatarConfig(kid.avatar);
                    const isSelected = selectedKidIds.includes(kid.id);
                    return (
                      <Button
                        key={kid.id}
                        variant={isSelected ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleKidSelection(kid.id)}
                        className={isSelected ? `bg-gradient-to-br ${config.color} text-white border-0` : ""}
                        data-testid={`toggle-kid-${kid.id}`}
                      >
                        <AvatarIcon avatar={kid.avatar} className="w-3 h-3 mr-1" />
                        {kid.name}
                      </Button>
                    );
                  })}
                </>
              )}
              {!assignToAll && kids.length === 0 && (
                <span className="text-xs text-muted-foreground">Add kids first.</span>
              )}
            </div>

            {/* Add button - full width */}
            <Button 
              variant="secondary"
              className="w-full"
              onClick={addVideo} 
              disabled={createVideoMutation.isPending || isResolvingUrl}
              data-testid="button-add-video"
            >
              {(createVideoMutation.isPending || isResolvingUrl) ? (
                <Loader2 className="w-3 h-3 mr-1 animate-spin" />
              ) : (
                <Plus className="w-3 h-3 mr-1" />
              )}
              {isResolvingUrl ? "Resolving..." : "Add"}
            </Button>
          </CardContent>
        </Card>

        {/* Video Preview Dialog */}
        <Dialog open={previewingVideoId !== null} onOpenChange={(open) => !open && setPreviewingVideoId(null)}>
          <DialogContent className={(() => {
            const previewVideo = previewingVideoId ? videos.find(v => v.id === previewingVideoId) : null;
            return previewVideo?.platform === "tiktok" 
              ? "max-w-[90vw] sm:max-w-[400px] p-2" 
              : "max-w-[95vw] sm:max-w-5xl p-2";
          })()}>
            <DialogHeader className="pb-1">
              <DialogTitle className="flex items-center gap-2 text-sm">
                <Play className="w-3 h-3" />
                Preview
              </DialogTitle>
            </DialogHeader>
            {(() => {
              const previewVideo = previewingVideoId ? videos.find(v => v.id === previewingVideoId) : null;
              if (!previewVideo) {
                return (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">Video not found</p>
                  </div>
                );
              }
              return (
                <div className={`bg-black rounded-lg overflow-hidden ${previewVideo.platform === "tiktok" ? "h-[80vh]" : "aspect-video w-full"}`}>
                  {previewVideo.platform === "tiktok" ? (
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.tiktok.com/embed/v2/${previewVideo.ytId}`}
                      title="TikTok video preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                      allowFullScreen
                    />
                  ) : (
                    <iframe
                      width="100%"
                      height="100%"
                      src={`https://www.youtube.com/embed/${previewVideo.ytId}?autoplay=1&rel=0`}
                      title="YouTube video preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  )}
                </div>
              );
            })()}
          </DialogContent>
        </Dialog>

        {/* Video Library */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Video className="w-4 h-4 text-purple-500" />
              Video Library ({videos.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {videos.length === 0 ? (
              <div className="text-center py-4">
                <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                  <Youtube className="w-5 h-5 text-purple-500" />
                </div>
                <p className="text-xs text-muted-foreground">No videos yet. Add a YouTube or TikTok link above!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Group by folders */}
                {[
                  { id: "unfiled", name: "Unfiled", videos: videos.filter(v => !v.folderId), isGlobal: false },
                  ...folders
                    .filter(folder => {
                      if (isMaster && folder.name.startsWith("__global_")) return false;
                      return true;
                    })
                    .map(folder => {
                    const globalMatch = folder.name.match(/^__global_(.+)$/);
                    const masterPlaylist = globalMatch ? globalPlaylists.find(gp => gp.id === globalMatch[1]) : null;
                    return {
                      id: folder.id,
                      name: masterPlaylist ? masterPlaylist.name : (globalMatch ? "Curated Playlist" : folder.name),
                      videos: videos.filter(v => v.folderId === folder.id),
                      isGlobal: !!globalMatch,
                    };
                  })
                ].filter(group => group.videos.length > 0).map(group => (
                  <div key={group.id} className="border rounded-lg overflow-hidden">
                    {/* Folder header */}
                    <button
                      onClick={() => toggleFolder(group.id)}
                      className="w-full flex items-center gap-2 p-2 bg-muted/50 text-left"
                      data-testid={`button-toggle-folder-${group.id}`}
                    >
                      {expandedFolders.has(group.id) ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                      <FolderIcon className={`w-4 h-4 ${group.isGlobal ? 'text-blue-500' : 'text-purple-500'}`} />
                      <span className="text-sm font-medium">{group.name}</span>
                      {group.isGlobal && (
                        <Badge variant="secondary" className="text-xs">
                          <Globe className="w-3 h-3 mr-0.5" />
                          Curated
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs ml-auto">
                        {group.videos.length}
                      </Badge>
                    </button>
                    
                    {/* Videos in folder */}
                    {expandedFolders.has(group.id) && (
                      <div className="p-2 space-y-2">
                        {group.videos.map(video => {
                          const viewCount = video.totalViews || 0;
                          const isMaxed = viewCount >= MAX_VIDEO_VIEWS;
                          const assignedKidNames = kids
                            .filter(k => video.assigned?.[k.id])
                            .map(k => k.name)
                            .join(", ");
                          
                          return (
                            <div
                              key={video.id}
                              className={`flex items-center gap-2 p-2 rounded-lg ${isMaxed ? 'bg-red-50 dark:bg-red-950/20' : 'bg-muted/30'}`}
                            >
                              {/* Thumbnail with preview button */}
                              <button
                                onClick={() => setPreviewingVideoId(video.id)}
                                className="w-16 h-10 rounded-md overflow-hidden bg-gray-200 dark:bg-gray-800 shrink-0 relative group"
                                data-testid={`button-preview-${video.id}`}
                              >
                                {video.platform === "tiktok" ? (
                                  <TikTokThumbnail videoId={video.ytId} className="w-full h-full" />
                                ) : (
                                  <img
                                    src={`https://img.youtube.com/vi/${video.ytId}/mqdefault.jpg`}
                                    alt="Video thumbnail"
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      e.currentTarget.style.display = 'none';
                                    }}
                                  />
                                )}
                                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Play className="w-4 h-4 text-white" />
                                </div>
                                {isMaxed && (
                                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                    <AlertTriangle className="w-4 h-4 text-red-400" />
                                  </div>
                                )}
                              </button>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-mono text-muted-foreground truncate">{video.ytId}</p>
                                <div className="flex flex-wrap items-center gap-1 mt-0.5">
                                  <Popover>
                                    <PopoverTrigger asChild>
                                      <button
                                        className="inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-semibold transition-colors bg-primary/10 border-primary/30 text-primary hover:bg-primary/20"
                                        data-testid={`button-level-${video.id}`}
                                        title="Tap to change level"
                                      >
                                        Lv.{video.priority || 5}
                                      </button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-2" align="start">
                                      <div className="grid grid-cols-5 gap-1">
                                        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((level) => (
                                          <button
                                            key={level}
                                            className={`w-8 h-8 rounded-md text-sm font-medium transition-colors ${
                                              (video.priority || 5) === level
                                                ? 'bg-primary text-primary-foreground'
                                                : 'bg-muted hover:bg-primary/20'
                                            }`}
                                            onClick={() => {
                                              updateVideoMutation.mutate({ videoId: video.id, priority: level });
                                            }}
                                            data-testid={`button-level-${video.id}-${level}`}
                                          >
                                            {level}
                                          </button>
                                        ))}
                                      </div>
                                    </PopoverContent>
                                  </Popover>
                                  <Badge variant={isMaxed ? "destructive" : "outline"} className="text-xs" data-testid={`badge-views-${video.id}`}>
                                    <Eye className="w-2 h-2 mr-0.5" />
                                    {viewCount}/{MAX_VIDEO_VIEWS}
                                  </Badge>
                                  {assignedKidNames && (
                                    <Badge variant="secondary" className="text-xs" data-testid={`badge-assigned-${video.id}`}>
                                      {assignedKidNames}
                                    </Badge>
                                  )}
                                  {/* Voice recordings from kids - show all recordings */}
                                  {kids.flatMap(kid => {
                                    const progress = video.progress?.[kid.id];
                                    if (!progress) return [];
                                    
                                    // Get all recordings (new array format + legacy single)
                                    const recordings: Array<{audioData?: string; recordedAt: string; duration: number}> = [];
                                    if (progress.voiceRecordings) {
                                      recordings.push(...progress.voiceRecordings);
                                    } else if (progress.voiceRecording?.audioData) {
                                      recordings.push(progress.voiceRecording);
                                    }
                                    
                                    return recordings.filter(r => r.audioData).map((recording, idx) => (
                                      <Button
                                        key={`audio-${kid.id}-${idx}`}
                                        variant="outline"
                                        size="sm"
                                        className="h-6 px-2 text-xs bg-green-50 dark:bg-green-950 border-green-300 dark:border-green-700 text-green-700 dark:text-green-300"
                                        onClick={() => {
                                          try {
                                            const audio = new Audio(recording.audioData);
                                            audio.play().catch(err => {
                                              console.error('Audio play failed:', err);
                                              toast({ title: "Could not play recording", variant: "destructive" });
                                            });
                                          } catch (err) {
                                            console.error('Audio creation failed:', err);
                                            toast({ title: "Could not play recording", variant: "destructive" });
                                          }
                                        }}
                                        data-testid={`button-play-recording-${video.id}-${kid.id}-${idx}`}
                                      >
                                        <Mic className="w-3 h-3 mr-1" />
                                        {kid.name}{recordings.length > 1 ? ` #${idx + 1}` : ''}
                                      </Button>
                                    ));
                                  })}
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="icon"
                                      data-testid={`button-move-folder-${video.id}`}
                                      title="Move to folder"
                                    >
                                      <FolderPlus className="w-3 h-3" />
                                    </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-48 p-2" align="end">
                                    <p className="text-xs font-medium text-muted-foreground mb-2">Move to folder</p>
                                    <div className="space-y-1">
                                      {video.folderId && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="w-full justify-start gap-2 text-xs"
                                          onClick={() => {
                                            updateVideoMutation.mutate({ videoId: video.id, folderId: null });
                                            toast({ title: "Moved to Unfiled" });
                                          }}
                                          data-testid={`button-move-unfiled-${video.id}`}
                                        >
                                          <FolderIcon className="w-3 h-3 text-muted-foreground" />
                                          Unfiled
                                        </Button>
                                      )}
                                      {folders
                                        .filter(f => !f.name.startsWith("__global_") && f.id !== video.folderId)
                                        .map(folder => (
                                          <Button
                                            key={folder.id}
                                            variant="ghost"
                                            size="sm"
                                            className="w-full justify-start gap-2 text-xs"
                                            onClick={() => {
                                              updateVideoMutation.mutate({ videoId: video.id, folderId: folder.id });
                                              toast({ title: `Moved to ${folder.name}` });
                                            }}
                                            data-testid={`button-move-to-${folder.id}-${video.id}`}
                                          >
                                            <FolderIcon className="w-3 h-3 text-purple-500" />
                                            {folder.name}
                                          </Button>
                                        ))
                                      }
                                      {folders.filter(f => !f.name.startsWith("__global_") && f.id !== video.folderId).length === 0 && !video.folderId && (
                                        <p className="text-xs text-muted-foreground p-1.5">No folders yet. Create one first.</p>
                                      )}
                                    </div>
                                  </PopoverContent>
                                </Popover>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => setPreviewingVideoId(video.id)}
                                  data-testid={`button-preview-icon-${video.id}`}
                                >
                                  <Play className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="destructive"
                                  size="icon"
                                  onClick={() => removeVideo(video.id)}
                                  disabled={deleteVideoMutation.isPending}
                                  data-testid={`button-delete-${video.id}`}
                                >
                                  {deleteVideoMutation.isPending ? (
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <Trash2 className="w-3 h-3" />
                                  )}
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Delete Folder Confirmation Dialog */}
        <AlertDialog open={deletingFolderId !== null} onOpenChange={(open) => !open && setDeletingFolderId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Folder?</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this folder? Videos in this folder will be moved to "Unfiled".
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-testid="button-cancel-delete-folder">Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deletingFolderId && deleteFolderMutation.mutate(deletingFolderId)}
                disabled={deleteFolderMutation.isPending}
                data-testid="button-confirm-delete-folder"
              >
                {deleteFolderMutation.isPending ? "Deleting..." : "Delete"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Activity Stats Dialog */}
        <Dialog open={activityStatsKidId !== null} onOpenChange={(open) => !open && setActivityStatsKidId(null)}>
          <DialogContent className="max-w-md">
            {activityStatsKidId && (() => {
              const kid = kids.find(k => k.id === activityStatsKidId);
              if (!kid) return null;
              const stats = getDetailedActivityStats(activityStatsKidId);
              const avatarConfig = getAvatarConfig(kid.avatar);
              return (
                <>
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarConfig.color} flex items-center justify-center text-white`}>
                        <AvatarIcon avatar={kid.avatar} className="w-4 h-4" />
                      </div>
                      {kid.name}'s Activity
                    </DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    {/* Overall Progress */}
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg p-4">
                      <div className="text-center mb-2">
                        <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">{stats.completionRate}%</div>
                        <div className="text-xs text-muted-foreground">Overall Completion</div>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all"
                          style={{ width: `${stats.completionRate}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1 text-muted-foreground">
                        <span>{stats.totalCompleted} completed</span>
                        <span>{stats.pending} pending</span>
                      </div>
                    </div>

                    {/* Time Period Stats */}
                    <div className="grid grid-cols-3 gap-2">
                      <button 
                        onClick={() => stats.completedToday > 0 && setActivityDetailView({ kidId: activityStatsKidId!, period: 'today' })}
                        className={`bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-center transition-all ${stats.completedToday > 0 ? 'hover-elevate cursor-pointer' : 'opacity-50'}`}
                        disabled={stats.completedToday === 0}
                        data-testid="button-activity-today"
                      >
                        <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stats.completedToday}</div>
                        <div className="text-xs text-muted-foreground">Today</div>
                      </button>
                      <button 
                        onClick={() => stats.completedThisWeek > 0 && setActivityDetailView({ kidId: activityStatsKidId!, period: 'week' })}
                        className={`bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-center transition-all ${stats.completedThisWeek > 0 ? 'hover-elevate cursor-pointer' : 'opacity-50'}`}
                        disabled={stats.completedThisWeek === 0}
                        data-testid="button-activity-week"
                      >
                        <div className="text-2xl font-bold text-green-600 dark:text-green-400">{stats.completedThisWeek}</div>
                        <div className="text-xs text-muted-foreground">Last 7 Days</div>
                      </button>
                      <button 
                        onClick={() => stats.completedThisMonth > 0 && setActivityDetailView({ kidId: activityStatsKidId!, period: 'month' })}
                        className={`bg-orange-50 dark:bg-orange-900/20 rounded-lg p-3 text-center transition-all ${stats.completedThisMonth > 0 ? 'hover-elevate cursor-pointer' : 'opacity-50'}`}
                        disabled={stats.completedThisMonth === 0}
                        data-testid="button-activity-month"
                      >
                        <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">{stats.completedThisMonth}</div>
                        <div className="text-xs text-muted-foreground">This Month</div>
                      </button>
                    </div>

                    {/* Last 7 Days Chart */}
                    <div>
                      <h4 className="text-sm font-medium mb-2">Last 7 Days</h4>
                      <div className="flex items-end gap-1 h-24">
                        {[...stats.last7Days].reverse().map((day, i) => {
                          const isToday = i === 0;
                          const daysAgo = i; // 0 = today, 1 = yesterday, etc
                          const maxCount = Math.max(...stats.last7Days.map(d => d.count), 1);
                          const height = day.count > 0 ? Math.max((day.count / maxCount) * 100, 15) : 8;
                          const handleDayClick = () => {
                            if (day.count > 0) {
                              const targetDate = new Date();
                              targetDate.setDate(targetDate.getDate() - daysAgo);
                              setActivityDetailView({ kidId: activityStatsKidId!, period: 'day', date: targetDate });
                            }
                          };
                          return (
                            <button 
                              key={i} 
                              className={`flex-1 flex flex-col items-center ${day.count > 0 ? 'cursor-pointer' : 'opacity-50'}`}
                              onClick={handleDayClick}
                              disabled={day.count === 0}
                              data-testid={`button-activity-day-${i}`}
                            >
                              <div className="text-lg font-bold text-purple-600 dark:text-purple-400 mb-1">
                                {day.count}
                              </div>
                              <div 
                                className={`w-full rounded-t transition-all ${day.count > 0 ? 'bg-gradient-to-t from-purple-500 to-pink-400' : 'bg-gray-200 dark:bg-gray-700'}`}
                                style={{ height: `${height}%` }}
                                title={`${day.date}: ${day.count} videos`}
                              />
                              <div className="text-[9px] text-muted-foreground mt-1 truncate w-full text-center">
                                {isToday ? 'Today' : day.date.split(' ')[0]}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Summary Stats */}
                    <div className="border-t pt-3">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Assigned:</span>
                          <span className="font-medium">{stats.totalAssigned}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Completed:</span>
                          <span className="font-medium text-green-600">{stats.totalCompleted}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })()}
          </DialogContent>
        </Dialog>

        {/* Activity Detail View Dialog */}
        <Dialog open={activityDetailView !== null} onOpenChange={(open) => {
          if (!open) {
            // Cleanup audio playback when closing
            if (activityAudioRef.current) {
              activityAudioRef.current.pause();
              activityAudioRef.current = null;
            }
            setPlayingAudioId(null);
            setActivityDetailView(null);
          }
        }}>
          <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
            {activityDetailView && (() => {
              const kid = kids.find(k => k.id === activityDetailView.kidId);
              if (!kid) return null;
              const periodVideos = getVideosForPeriod(activityDetailView.kidId, activityDetailView.period, activityDetailView.date) as VideoType[];
              const avatarConfig = getAvatarConfig(kid.avatar);
              
              const getPeriodTitle = () => {
                if (activityDetailView.period === 'today') return "Today's Videos";
                if (activityDetailView.period === 'week') return "Last 7 Days' Videos";
                if (activityDetailView.period === 'month') return "This Month's Videos";
                if (activityDetailView.period === 'day' && activityDetailView.date) {
                  const isToday = new Date().toDateString() === activityDetailView.date.toDateString();
                  if (isToday) return "Today's Videos";
                  return activityDetailView.date.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
                }
                return "Videos";
              };
              
              return (
                <>
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8"
                        onClick={() => setActivityDetailView(null)}
                        data-testid="button-back-to-stats"
                      >
                        <ArrowLeft className="w-4 h-4" />
                      </Button>
                      <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${avatarConfig.color} flex items-center justify-center text-white`}>
                        <AvatarIcon avatar={kid.avatar} className="w-3 h-3" />
                      </div>
                      {getPeriodTitle()}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-3">
                    {periodVideos.length === 0 ? (
                      <div className="text-center text-muted-foreground py-8">
                        No videos watched in this period
                      </div>
                    ) : (
                      periodVideos.map((video: VideoType) => {
                        const progress = video.progress?.[activityDetailView.kidId];
                        const recordings = progress?.voiceRecordings || (progress?.voiceRecording ? [progress.voiceRecording] : []);
                        const watchedAt = progress?.watchedAt ? new Date(progress.watchedAt) : null;
                        
                        return (
                          <div key={video.id} className="flex gap-3 p-2 rounded-lg bg-muted/30" data-testid={`activity-video-${video.id}`}>
                            {/* Video Thumbnail - clickable to preview */}
                            <button
                              onClick={() => {
                                // Cleanup audio playback before opening video
                                if (activityAudioRef.current) {
                                  activityAudioRef.current.pause();
                                  activityAudioRef.current = null;
                                }
                                setPlayingAudioId(null);
                                setActivityDetailView(null);
                                setPreviewingVideoId(video.id);
                              }}
                              className="relative flex-shrink-0 w-24 h-16 rounded overflow-hidden hover-elevate"
                              data-testid={`button-play-video-${video.id}`}
                            >
                              <img
                                src={video.platform === 'youtube' 
                                  ? `https://img.youtube.com/vi/${video.ytId}/mqdefault.jpg`
                                  : `https://www.tiktok.com/api/img/?itemId=${video.ytId}`
                                }
                                alt={`Video ${video.ytId.slice(0, 8)}`}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 90"><rect fill="%23333" width="120" height="90"/><text x="50%" y="50%" fill="%23999" text-anchor="middle" dy=".3em" font-size="12">Video</text></svg>';
                                }}
                              />
                              <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                <Play className="w-6 h-6 text-white" />
                              </div>
                            </button>
                            
                            {/* Video Info & Audio */}
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium truncate">Video {video.ytId.slice(0, 8)}</div>
                              {watchedAt && (
                                <div className="text-xs text-muted-foreground">
                                  {watchedAt.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                                </div>
                              )}
                              
                              {/* Audio Recordings */}
                              {recordings.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {recordings.map((rec, idx) => {
                                    const audioId = `${video.id}-${idx}`;
                                    const isPlaying = playingAudioId === audioId;
                                    return (
                                      <Button
                                        key={idx}
                                        size="sm"
                                        variant={isPlaying ? "default" : "outline"}
                                        className="h-7 px-2 text-xs"
                                        onClick={() => {
                                          if (isPlaying) {
                                            activityAudioRef.current?.pause();
                                            setPlayingAudioId(null);
                                          } else {
                                            if (activityAudioRef.current) {
                                              activityAudioRef.current.pause();
                                            }
                                            const audio = new Audio(rec.audioData);
                                            activityAudioRef.current = audio;
                                            audio.onended = () => setPlayingAudioId(null);
                                            audio.play();
                                            setPlayingAudioId(audioId);
                                          }
                                        }}
                                        data-testid={`button-play-audio-${video.id}-${idx}`}
                                      >
                                        {isPlaying ? <Square className="w-3 h-3 mr-1" /> : <Mic className="w-3 h-3 mr-1" />}
                                        {Math.round(rec.duration)}s
                                      </Button>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </>
              );
            })()}
          </DialogContent>
        </Dialog>

        {/* Delete Video Confirmation Dialog */}
        <AlertDialog open={deletingVideoId !== null} onOpenChange={(open) => !open && setDeletingVideoId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Video?</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to remove this video from the library? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-testid="button-cancel-delete-video">Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deletingVideoId && deleteVideoMutation.mutate(deletingVideoId)}
                disabled={deleteVideoMutation.isPending}
                data-testid="button-confirm-delete-video"
              >
                {deleteVideoMutation.isPending ? "Deleting..." : "Delete"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
